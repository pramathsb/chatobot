#!/bin/sh
# Defines the Solr schema for Drupal-style content and loads the sample documents.
# Idempotent: safe to run on every start (fields that already exist are ignored, documents are upserted by id).
SOLR="${SOLR_URL:-http://solr:8983/solr/content}"
JSON='Content-type:application/json'

echo "waiting for Solr at $SOLR ..."
until curl -sf "$SOLR/admin/ping" >/dev/null 2>&1; do sleep 2; done
echo "Solr is up"

add_field() {
  curl -s -X POST -H "$JSON" "$SOLR/schema" -d "{\"add-field\": $1}" | grep -q '"errors"' && echo "  (exists) $2" || echo "  added $2"
}
add_field '{"name":"nid","type":"string","stored":true,"indexed":true}' nid
add_field '{"name":"type","type":"string","stored":true,"indexed":true}' type
add_field '{"name":"title","type":"text_en","stored":true,"indexed":true}' title
add_field '{"name":"body","type":"text_en","stored":true,"indexed":true}' body
add_field '{"name":"tags","type":"text_en","stored":true,"indexed":true,"multiValued":true}' tags
add_field '{"name":"url","type":"string","stored":true,"indexed":true}' url
add_field '{"name":"updated","type":"pdate","stored":true,"indexed":true}' updated
add_field '{"name":"office","type":"string","stored":true,"indexed":true}' office
add_field '{"name":"holiday_name","type":"string","stored":true,"indexed":true}' holiday_name
add_field '{"name":"holiday_date","type":"pdate","stored":true,"indexed":true}' holiday_date

echo "loading documents"
for f in /seed/content.json /seed/holidays.json; do
  echo "  $f"; curl -s -X POST -H "$JSON" "$SOLR/update?commit=true" --data-binary @$f | grep -o "\"status\":[0-9]*"
done
echo
echo "documents in index:"
curl -s "$SOLR/select?q=*:*&rows=0" | grep -o '"numFound":[0-9]*'
