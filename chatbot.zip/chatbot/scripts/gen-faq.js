// Generates the mock FAQ workbook: data/faq.xlsx
// Run (no local Node needed):  docker run --rm -v "%cd%:/work" -w /work node:20-slim sh -c "npm i --no-save exceljs && node scripts/gen-faq.js"
const ExcelJS = require('exceljs');
const path = require('path');

const rows = [
  ['FAQ-001', 'Policy', 'What are the office working hours?', 'how many hours do we work; what time does office start; office timings; shift timings',
    'Standard working hours are 9:00 AM to 6:00 PM, Monday to Friday, with a 1-hour lunch break. Core hours (when everyone should be available) are 10:30 AM to 4:30 PM.'],
  ['FAQ-002', 'Policy', 'What is the work from home policy?', 'can I work from home; how many WFH days are allowed; remote work policy; hybrid work rules',
    'Employees may work from home up to 2 days per week with manager approval. WFH days must be marked in the attendance portal by 10:00 AM on the day.'],
  ['FAQ-003', 'Leave', 'How do I apply for leave?', 'how to request leave; steps to apply for leave; where do I submit a leave request; leave application process',
    'Log in to the HR portal, go to Leave > Apply Leave, choose the leave type and dates, and submit. Your manager receives the request and you are notified once it is approved or rejected.'],
  ['FAQ-004', 'Leave', 'How many annual leaves am I entitled to?', 'annual leave entitlement; how many paid leaves per year; yearly leave quota',
    'Full-time employees are entitled to 20 annual leaves, 10 sick leaves and 8 casual leaves per calendar year.'],
  ['FAQ-005', 'Leave', 'Can I carry forward unused leave to next year?', 'leave carry forward; do unused leaves expire; leave encashment; leave rollover',
    'Up to 5 unused annual leaves can be carried forward to the next year. Sick and casual leaves lapse on 31 December. Leave encashment is not available.'],
  ['FAQ-006', 'Leave', 'Do I need a medical certificate for sick leave?', 'sick leave certificate; doctor note for sick leave; medical proof for leave',
    'A medical certificate is required if you take sick leave for more than 2 consecutive days.'],
  ['FAQ-007', 'Leave', 'What is the maternity and paternity leave policy?', 'maternity leave duration; paternity leave days; parental leave',
    'Maternity leave is 26 weeks paid. Paternity leave is 10 working days paid, to be taken within 6 months of the childs birth.'],
  ['FAQ-008', 'Payroll', 'When is salary credited?', 'salary date; when do I get paid; payday; salary credit date',
    'Salaries are credited on the last working day of each month.'],
  ['FAQ-009', 'Payroll', 'Where can I download my payslip?', 'how to get payslip; payslip download; salary slip; view my payslip',
    'Payslips are available in the HR portal under Payroll > My Payslips. They are published within 2 working days after salary credit.'],
  ['FAQ-010', 'Payroll', 'How do I submit reimbursement claims?', 'expense claim process; how to claim travel expenses; reimbursement form; submit bills',
    'Submit claims in the HR portal under Finance > Expense Claims with scanned receipts within 30 days of the expense. Approved claims are paid with the next payroll.'],
  ['FAQ-011', 'Attendance', 'What happens if I forget to punch in or out?', 'missed punch; forgot to check in; attendance regularization; fix attendance entry',
    'Raise an attendance regularization request in the HR portal within 3 working days. Your manager must approve it.'],
  ['FAQ-012', 'Attendance', 'How many late marks are allowed per month?', 'late coming policy; late arrival penalty; grace period for late; how many times can I be late',
    'Arriving after 9:15 AM is a late mark. Three late marks in a month are counted as a half-day leave.'],
  ['FAQ-013', 'Policy', 'What is the dress code?', 'what should I wear to office; dress policy; casual friday; formal dress code',
    'Business casual is the standard dress code. Casual wear (jeans, t-shirts) is allowed on Fridays and on days without client meetings.'],
  ['FAQ-014', 'IT', 'How do I reset my password?', 'forgot my password; password reset; login not working; account locked',
    'Use the "Forgot password" link on the login page, or contact the IT helpdesk at helpdesk@example.com / extension 1100.'],
  ['FAQ-015', 'IT', 'How do I contact the IT helpdesk?', 'IT support number; laptop not working; raise an IT ticket; helpdesk email',
    'Email helpdesk@example.com or dial extension 1100. Support is available 8:00 AM to 8:00 PM on working days.'],
  ['FAQ-016', 'Benefits', 'What health insurance benefits do I get?', 'medical insurance coverage; mediclaim; health cover for family; insurance policy details',
    'All employees get group health insurance of 500,000 per year covering self, spouse and up to 2 children. Parents can be added at a discounted premium.'],
  ['FAQ-017', 'Benefits', 'Does the company reimburse learning and certifications?', 'training budget; course reimbursement; certification support; learning allowance',
    'Yes. Each employee has an annual learning budget of 1,500 for approved courses and certifications. Get manager approval before enrolling.'],
  ['FAQ-018', 'HR', 'How do I contact HR?', 'HR email; HR phone number; who do I talk to for HR queries; HR helpdesk',
    'Email hr@example.com or visit the HR desk on the 2nd floor, 10:00 AM to 5:00 PM.'],
  ['FAQ-019', 'HR', 'What is the notice period for resignation?', 'how much notice do I need to give; resignation process; notice period buyout; how to resign',
    'The notice period is 60 days for confirmed employees and 30 days during probation. Submit your resignation through the HR portal under Exit > Resign.'],
  ['FAQ-020', 'HR', 'How long is the probation period?', 'probation duration; when will I be confirmed; confirmation process; probation leave rules',
    'The probation period is 6 months. You will receive a confirmation letter after a satisfactory review.'],
];

(async () => {
  const wb = new ExcelJS.Workbook();
  const ws = wb.addWorksheet('FAQ');
  ws.columns = [
    { header: 'id', key: 'id', width: 10 },
    { header: 'category', key: 'category', width: 12 },
    { header: 'question', key: 'question', width: 50 },
    { header: 'variants', key: 'variants', width: 70 },
    { header: 'answer', key: 'answer', width: 90 },
  ];
  rows.forEach(([id, category, question, variants, answer]) => ws.addRow({ id, category, question, variants, answer }));
  ws.getRow(1).font = { bold: true };
  ws.views = [{ state: 'frozen', ySplit: 1 }];
  const out = path.join(__dirname, '..', 'data', 'faq.xlsx');
  await wb.xlsx.writeFile(out);
  console.log('wrote', out, rows.length, 'rows');
})();
