// 250 virtual users, each with its own identity, asking a realistic mix of questions with think time.
// Run:  docker run --rm -i --network chatbot_default -e BASE=http://api:3000 grafana/k6 run - < loadtest/k6.js
import http from 'k6/http';
import { check, sleep } from 'k6';
import { Trend, Rate } from 'k6/metrics';

const BASE = __ENV.BASE || 'http://localhost:3000';
const VUS = Number(__ENV.VUS || 250);
const DURATION = __ENV.DURATION || '2m';

export const options = {
  scenarios: { chat: { executor: 'constant-vus', vus: VUS, duration: DURATION } },
  thresholds: { http_req_failed: ['rate<0.01'], chat_ms: ['p(95)<8000'] },
};

const chatMs = new Trend('chat_ms', true);
const llmUsed = new Rate('llm_used');
const errors = new Rate('answered_ok');

// mix: mostly FAQ / direct tool hits, some needing the LLM, some out of scope
const QUESTIONS = [
  'what is my leave balance', 'what are the public holidays', 'what time does the office open',
  'how do I apply for leave', 'show my attendance', 'when is the next holiday',
  'show my leave history', 'how do I get my payslip', 'how many sick leaves do I have left',
  'my attendance two months ago', 'can I work from home on fridays', 'show my attendance last month',
  'who won the world cup', 'what is the notice period for resignation',
];

export default function () {
  if (__ITER === 0) sleep(Math.random() * 30); // users do not all arrive in the same instant
  const token = `load-${__VU}`;
  const q = QUESTIONS[Math.floor(Math.random() * QUESTIONS.length)];
  const res = http.post(`${BASE}/api/chat`, JSON.stringify({ message: q }), {
    headers: { 'content-type': 'application/json', authorization: `Bearer ${token}` },
    timeout: '60s',
  });
  chatMs.add(res.timings.duration);
  let ok = res.status === 200;
  if (ok) {
    const b = res.json();
    llmUsed.add(b.debug && b.debug.llmUsed);
    ok = b.source !== 'error';
  }
  errors.add(ok);
  check(res, { 'status 200': (r) => r.status === 200 });
  sleep(8 + Math.random() * 20); // think time 8-28 s
}
