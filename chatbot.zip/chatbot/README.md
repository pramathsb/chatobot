# HR Chatbot POC (on-prem LLM, closed-domain)

Everything runs in Docker. No GPU, no Python.

```
React (nginx :8080) ─> NestJS gateway (:3000) ─┬─> embeddings (MiniLM/ONNX, in-process)
                                               ├─> llama.cpp server (:8081)  Qwen2.5-1.5B Q4 (CPU)
                                               ├─> mock-hr (:4000)  attendance / leave / holidays
                                               ├─> Solr (:8983) core "content"  Drupal-style pages (mock data)
                                               └─> data/faq.xlsx + data/catalogue.json + data/dictionaries.json  (the allowed questions and rules)
```

## Run

```bash
docker compose up -d --build
```

First start downloads the GGUF model (~1.1 GB) and the embedding model (~25 MB); the chat works
without the LLM meanwhile (it degrades to "did you mean…"). Check `http://localhost:3000/api/health`.

- UI: http://localhost:8080 (switch demo user top-right)
- API: `POST http://localhost:3000/api/chat` with `Authorization: Bearer demo-token-emp001`, body `{"message":"..."}`
- Demo tokens: `demo-token-emp001` … `demo-token-emp005`; `load-<n>` works for load tests.

## How a question is handled

1. **Guard** (no model): length, prompt-injection patterns, "other employee's data" patterns, per-user rate limit and one in-flight request per user.
2. **Answer to my last question?** If the bot asked something (a confirmation, or a missing month / office) the client echoes that `pending` state back and the reply is treated as the answer. Asking a different question instead simply drops it.
3. **Exact match** (deterministic, no model): the normalised message equals a rule's `searchTerm`/alias or a bare domain word.
   - a **bare domain word** ("leave", "holiday", "attendance", "salary") → a short **menu** of that domain's rules
   - a **rule alias** ("leave balance", "apply leave", "payslip") → that rule directly
   - **utility rules**: `hi`/`hello`/`help` → welcome, `repeat` → re-run the last result, "talk to a human" → escalation offer
4. **PDF export** ("give me this in pdf", "attendance for august as pdf") → the same table as a PDF. The reply carries an `export` reference and the UI downloads it via `POST /api/export/pdf` (token in the header, rule must be `exportable`, params whitelisted).
5. **Semantic match** against FAQs and searchable rules by embedding similarity (holiday and office spelling variants are normalised first, e.g. "deepavali" → "Diwali", "bombay" → "Mumbai").
   - score ≥ 0.75, or ≥ 0.65 with a clear margin → go straight ahead (no LLM)
   - 0.50–0.75 → a real Solr hit wins, otherwise the LLM picks one of the top-3 or `none` (grammar-constrained JSON)
   - < 0.50 → content search in Solr, else a refusal that also **offers to send the question to HR support**
6. **Run the rule by its mode** (see "Rule catalogue" below). FAQ answers come verbatim from Excel; HR data comes from read-only calls made with the caller's own token. The LLM never writes answer text.
7. Entities (month, range, leave type, holiday, office…) come from regex and the dictionaries; the LLM (schema-constrained) is only a last resort for time phrases the rules can't resolve. A rule with a **required** entity (attendance period, office) asks for it instead of guessing.

## Rule catalogue (`data/catalogue.json`)

The catalogue is organised by **intent**, not by domain: one rule = one distinct question = (ideally) one action, so a specific query resolves directly, and only a bare domain word shows a menu.

| Mode | Types | Behaviour | Examples |
|---|---|---|---|
| **A** conversational data query | `api_view` | no menu, no confirm; collect missing entities, call the API, format the answer, offer PDF | `leave_balance`, `leave_history`, `attendance_summary`, `holiday` |
| **B** navigation | `intranet_page` | direct link card, no confirmation | `visitor_pass`, `id_card`, `travel`, `facility_booking` |
| **C** external portal / write | `portal`, `api_action` | **confirm first** (Yes / No), then the link | `apply_leave`, `payslip`, `leave_approvals` (managers), `team_attendance` (managers) |
| **D** content lookup | `drupal_search` | Solr; either ranked excerpts, or a grouped aggregation | `leave_policy`, `holiday_policy`, `holiday_all_offices`, `holiday_office` |
| **U** utility | `utility` | exact match only, never semantic | `greeting`, `help`, `repeat`, `escalate_to_support` |

Rule fields: `id, domain, mode, type, searchTerm, label, aliases, keywords, sampleUtterances, entities[], roles, confirmMessage, target, apiMethodKey, searchQuery, exportable, searchable, priority, active`. The `apiMethodKey` is an explicit lookup key (`quota_overview`, `leave_overview`, `attendance_overview`, `view_holidays`, `holiday_calendar_all`, `holiday_calendar_office`) into the executor, not a URL string. Rules with `roles: ["manager"]` are hidden from other users' menus and refused if asked directly (`emp002` and `emp003` are managers in the mock).

**Three holiday variants** share vocabulary but differ in source and scope:

| Query | Rule | Source |
|---|---|---|
| "when is Diwali for me", "upcoming holidays", "optional holidays", "is today a holiday", "long weekend in December", "holidays between 1 Jan and 31 Jan" | `holiday` (A) | HR API, employee's own location (the API has no location parameter) |
| "holidays across offices", "which offices get Diwali off" | `holiday_all_offices` (D) | Solr per-office calendar, **grouped** by `HolidayAggregationFormatter` (pivot table + "where offices differ") |
| "Chennai office holidays", "is Diwali a holiday in Chennai" | `holiday_office` (D) | Solr, one office; asks "Which office?" if not named |

Disambiguation is deterministic: "across / all offices / compare" → all offices; a named office → that office; "for me / my" → personal (this wins over a named office); bare "holiday" → the menu.

**Dictionaries** (`data/dictionaries.json`) are closed vocabularies with spelling variants for holiday names, leave types (CL/SL/EL) and offices. They drive entity extraction and query normalisation, and are exported together with all aliases to `data/generated/synonyms_bot.txt` (also `GET /api/admin/synonyms`) for Solr's synonym filter, so Solr and the catalogue stay in sync by construction.

**Escalation:** every refusal / "did you mean" offers a *Send this to HR support* button → `POST /api/escalate`, which appends a ticket to `data/escalations.jsonl` (stand-in for the email/notification) **and** the unanswered query to `data/candidate_rules.jsonl` (the catalogue-improvement backlog). Each reply carries a `correlationId` shown in the UI.

## Change the knowledge

Edit `data/faq.xlsx` (columns: `id, category, question, variants (;-separated), answer`) or add a
`data/faq.json` (same fields as an array). Rules and domains live in `data/catalogue.json`, dictionaries in `data/dictionaries.json`.
All are hot-reloaded within ~3 s (or `POST /api/admin/reload`). Regenerate the sample workbook with `scripts/gen-faq.js`.

## Conversation tests

```bash
docker run --rm --network chatbot_default -e BASE=http://api:3000 -v "%cd%/tests:/t" node:20-slim node /t/conversations.mjs
```

101 scripted checks against the live stack: specific vs bare queries, every mode, roles, multi-turn entity prompts, interruption, the three holiday variants, dictionary variants, utility intents, PDF export (including non-exportable and invalid requests), escalation and the synonyms export, plus earlier FAQ / content / refusal / injection regressions. Needs no LLM for these scenarios, only the stack.


## Conversational rule catalogue spec: what was applied here

The "Nayara Hub: Conversational Intent & Action Rule Catalogue" spec targets a different codebase (`middleware/src/search/search.service.ts`, the Drupal `conversational_action`
module, `MyEquationsAdapter`). Those files are not in this repo, so the spec's **design** was applied to this POC's equivalents:

| Spec | Applied here |
|---|---|
| §2 principles, §3.1 split compound domains into intent-level rules | `catalogue.json`: one rule per question; bare domain word → menu, specific phrasing → direct (`leave`, `attendance`, `holiday`, `payroll`, `id card`, `training`, `facility`) |
| §2 modes A-D | `mode` on every rule; B direct link, C confirm-then-link, D Solr, A data query |
| §3.2 re-type MyEquations-backed rules `portal` → `api_view` | leave balance / history, attendance, holidays are `api_view`; `payslip`, apply leave, approvals, team attendance stay `portal` (confirm) |
| §3.1.1-3.1.2 holiday variants (personal / all offices / one office; name, upcoming, month, type, range, long weekend, today/tomorrow) | rules `holiday`, `holiday_all_offices`, `holiday_office`; `HolidayAggregationFormatter` for the grouped answer; mock HR returns public and optional holidays as two collections |
| §3.3 utility intents, contextual PDF, `escalate_to_support` | `greeting`, `help`, `repeat`, PDF follow-up, escalation + candidate-rule backlog |
| §4.4 entities / multi-turn | `entities[]` on rules; attendance period and office are required and prompted; short answers and interruption handled |
| §9 content model (`conversation_mode`, `api_method_key`, `entity_definition`, `role_policy`, `sample_utterances`, `active_flag`, `priority`) | the same fields in `catalogue.json` (`mode`, `apiMethodKey`, `entities`, `roles`, `sampleUtterances`, `active`, `priority`) |
| §10.1 / §10.2 synonyms export, dictionary-based entities | `data/generated/synonyms_bot.txt` regenerated on every reload; `dictionaries.json` (holiday names, leave types, offices) |
| §6 test plan (shape tests, conversation scripts) | `tests/conversations.mjs` |

**Not applicable here / not done:** the Drupal import script and the three duplicated copies of the dataset (no Drupal module in this repo); `getPhase1RuleSet()` fallback
consolidation; Solr OpenNLP NER chain (this POC normalises with dictionaries and regex in the gateway); the Analytics spec (rule effectiveness reporting); payslip as `api_view`
(left as `portal`, as the spec says). The interruption flow drops the pending question and answers the new one, rather than asking "Switch from X to Y?".

## Content search (Solr)

`docker compose up` also starts **Solr 9** (core `content`, http://localhost:8983) and a one-shot `solr-seed` job that defines the
schema (`nid, type, title, body, tags, url, updated`) and loads 15 Drupal-style pages from `data/solr/content.json` and 44 per-office holiday records from `data/solr/holidays.json`
(travel policy, code of conduct, security guidelines, onboarding, referral program, remote work, …).

How the bot uses it (`api/src/solr.service.ts`, `contentOrRefuse` in `chat.service.ts`):

1. FAQs and HR lookups always win. Only when the question is **not** matched to one of them is Solr searched.
2. The question is cleaned (question words and generic words like "policy" removed, Solr syntax stripped so users cannot inject
   queries) and sent to Solr with `edismax` over `title^3 tags^2 body`, with highlighted passages.
3. **Two relevance gates** must pass: Solr's keyword score (`SOLR_MIN_SCORE`, default 1.5) **and** a meaning check: the question's
   embedding must be close to the hit's title or excerpt (`SOLR_MIN_SIM`, default 0.37). The second gate removes stem collisions
   such as "programming language" matching "Referral Program".
4. The reply is **extractive**: the page title, type, an excerpt from the page, and a link (`INTRANET_BASE_URL` + the page's URL alias).
   The LLM writes nothing. If nothing passes the gates the normal refusal is returned.
5. In the uncertain band, a real Solr hit beats a weak FAQ guess; an LLM pick that is itself a weak match is discarded.

Try it: "is there a gym in the office", "what is the hotel limit for business travel", "how do I request a new laptop",
"how many characters should my password have", "search code of conduct".

Add or change content (no restart): edit `data/solr/content.json`, then
`docker compose run --rm solr-seed` (upserts by `id`). To connect the real index, set `SOLR_URL` to your core and make sure it has
the same field names (the per-office holiday calendar also needs `type=holiday_calendar`, `office`, `holiday_name`, `holiday_date`; or adjust `fl` / `qf` in `solr.service.ts`), and set `INTRANET_BASE_URL` to the Drupal site.
The two thresholds were tuned on this small sample (32 test questions: 12 content, 4 FAQ, 4 HR, 12 refusals all passed), so re-tune them on real content.

## Load test (250 users)

```bash
docker run --rm -i --network chatbot_default -e BASE=http://api:3000 grafana/k6 run -q - < loadtest/k6.js
```

Result on a dev laptop (1.5B model, 8 LLM threads, everything else sharing the same CPU), 250 users with
8–28 s think time (~10 req/s, far above realistic): 0 errors, median 85 ms, p95 5.9 s. ~86% of requests never touch
the LLM. The LLM path is the bottleneck, so it sheds load (4 s max slot wait) rather than queueing forever.

## Layout

| Path | What |
|---|---|
| `mock-hr/` | Express mock of the HR APIs (deterministic data per employee) |
| `data/catalogue.json`, `data/dictionaries.json` | rule catalogue (modes A-D/U, domains, entities) and closed-vocabulary dictionaries |
| `api/src/chat.service.ts` | routing by mode, menus, confirm / entity multi-turn, utility intents |
| `api/src/entity.service.ts` | dates, ranges, leave type, holiday, office extraction (regex + dictionaries, LLM last resort) |
| `api/src/executor.service.ts` | runs a rule by `apiMethodKey` (HR API or Solr); shared with PDF export |
| `api/src/holiday-aggregation.formatter.ts` | groups per-office holiday docs into a pivot / comparison |
| `api/src/escalation.service.ts` | escalation tickets + catalogue-candidate backlog |
| `tests/conversations.mjs` | 101 scripted conversation checks |
| `api/src/knowledge.service.ts` | Excel/JSON loader, hot reload, embedding + lexical matching |
| `api/src/tools.service.ts` | allow-listed HR API methods, caching, formatting |
| `api/src/llm.service.ts` | llama.cpp client, slot semaphore, bounded wait |
| `api/src/solr.service.ts` | Solr search, query cleaning, semantic relevance check |
| `api/src/pdf.service.ts` | PDF reports for table answers |
| `solr-seed/`, `data/solr/` | Solr schema + sample Drupal-style content loader |
| `api/src/guard.service.ts` | input guard, rate limits |
| `web/` | React chat UI (shows source / route / score / latency per answer) |
| `loadtest/k6.js` | 250-user scenario |

## POC shortcuts (not for production)

- Auth is a bearer token looked up by the mock; replace with your real session/JWT and forward it to the HR APIs.
- Rate limits, caches and the LLM queue are in-memory (single api instance). Use Redis/BullMQ to scale out.
- JSON responses, not SSE streaming (answers are templated and short).
- 1.5B model chosen for laptop speed. On the target 64-core box use a 3–8B Q4 model, `LLM_MODEL`,
  `LLM_THREADS`, and consider 2–4 llama-server instances pinned per NUMA node.
- Solr here holds sample content, keyword search + a semantic relevance filter. For production: index real Drupal content (Search API Solr),
  consider chunking long pages into passages, dense-vector or hybrid retrieval, and per-role access filters (`fq`) so users only see pages they may read.

---

# Technical Design Document (written for non-technical readers)

**Contents:** 1 Summary · 2 Goals · 3 The big idea · 4 The building blocks · 5 Life of a question · 6 Guardrails · 7 Where answers come from · 8 The AI model · 9 Serving 250 people · 10 Security and privacy · 11 Greeting and PDF · 12 Technology choices · 13 Limitations · 14 Roadmap · 15 Glossary

## 1. Summary

We built a chat assistant for employees. Instead of logging in to several screens, an employee types a question such as *"How many sick leaves do I have left?"* or *"What are the public holidays?"* and gets an answer in seconds. They can also ask for any table as a **PDF**.

The assistant is deliberately **narrow**. It only answers questions that the company has approved in a list (an Excel or JSON file) and four things it can look up from the HR system: **attendance, leave balance, leave history and public holidays**. Anything else, such as "write me a poem" or "who won the cricket match", gets a polite refusal.

An AI language model runs **inside the company's own server room** (on-premises). No question or employee data is sent to the internet. The AI is used sparingly, as a helper that resolves unclear wording, never as the author of answers. This is the main reason it stays accurate and safe.

## 2. Goals

**What success looks like**
- Employees get correct answers about **their own** attendance and leave, and company policy, in a few seconds.
- The assistant **never** answers outside the approved topics and **never** shows one person's data to another.
- It runs on **one on-premises server** (64 CPU cores, 32 GB memory, no graphics card) and copes with **up to 250 people** using it.
- HR can change the approved questions by editing an Excel file, with no developer needed.
- It fits the existing company systems (React website, NestJS server, Drupal) and can later search Drupal content through Solr.

**Not goals (for now):** open-ended chat, writing emails or documents, changing data (applying for leave), or answering from the internet.

## 3. The big idea: a receptionist, not an encyclopedia

Imagine a very capable receptionist with a binder of approved answers and four filing cabinets they may open **only for the person standing in front of them**.

1. Someone asks a question. The receptionist first checks it is a reasonable, safe question.
2. They find the closest match in the binder. If it is a clear match, they read out the approved answer **word for word**.
3. If the question is about the person's own attendance or leave, they open the right cabinet **for that person only**, read the facts, and present them in a fixed format.
4. If the question is not in the binder and not about the cabinets, they say: *"I can only help with these topics,"* and suggest a few examples.
5. Only when the wording is genuinely confusing ("two months ago", or two similar-sounding questions) does the receptionist ask a **junior colleague (the AI model)** for a second opinion. The colleague can only pick from a short list of options the receptionist hands over. They cannot invent an answer.

**Why not just let the AI answer everything?** On a server without a graphics card, a language model is slow (a few words per second) and it can make things up. Using it as a "second opinion on wording" makes the system fast, cheaper to run and far more predictable. About **86% of questions never touch the AI model at all**.

## 4. The building blocks

```
   Employee's browser
          |
          v
 +------------------+     +---------------------------------------------+
 | 1. Chat screen   |     | 2. Gateway (the "receptionist")             |
 |   (React website)| --> |   safety checks, matching, routing, PDFs    |
 +------------------+     +----+------------+-------------+-------------+
                               |            |             |
                               v            v             v
                    +----------------+ +-------------+ +---------------------+
                    | 3. AI model    | | 4. Search   | | 5. HR system        |
                    | (llama.cpp,    | |    brain    | |  attendance, leave, |
                    |  on our server)| | (embeddings)| |  holidays (APIs)    |
                    +----------------+ +------+------+ +---------------------+
                                              ^
                                              |
                                 Approved questions file (Excel / JSON)
```

| # | Part | In plain words | Where in the project |
|---|---|---|---|
| 1 | **Chat screen** | The website window where people type. Shows messages, tables, suggested-question buttons and the Download PDF button. | `web/` |
| 2 | **Gateway** | The central coordinator (built with NestJS, like the existing company server). It runs the safety checks, decides what the user is asking, calls the right source, and builds the reply. | `api/` |
| 3 | **AI model** | A small language model that runs on the company CPU through a program called *llama.cpp*. Used only for tie-breaking and for understanding phrases like "two months ago". | `llm` service in `docker-compose.yml` |
| 4 | **Search brain** | A small helper that turns a sentence into numbers capturing its *meaning*, so "How do I get my salary slip?" matches "Where can I download my payslip?" even with different words. | `api/src/embedding.service.ts` |
| 5 | **Company content (Solr)** | The search engine holding the intranet pages written in Drupal. The gateway searches it when a question is not an FAQ or HR lookup. In this proof of concept it holds 12 sample pages. | `solr` service, `data/solr/` |
| 6 | **HR system** | The company system holding attendance, leave and holidays. In this proof of concept it is a **mock** (a stand-in with realistic fake data) in the `mock-hr/` folder. | `mock-hr/` |

Everything is packaged in **Docker**, a way of shipping each part as a sealed box, so the whole system starts with one command (`docker compose up -d --build`) on any server.

## 5. Life of a question

Every message follows the same path:

1. **Arrives** at the gateway with the employee's login token (their ID badge).
2. **Identity check:** the gateway asks the HR system "who is this token?". No valid badge means no answer.
3. **Safety check (no AI involved):** too long? Trying to trick the bot ("ignore your instructions")? Asking about someone else ("show leave of emp002")? Sending too many messages? Any of these are stopped with a fixed reply.
4. **Is it a greeting?** ("hi", "hello", "help") shows the welcome message.
5. **Is it a PDF request?** ("give me this in pdf") goes to the PDF path (section 11).
6. **Find the closest approved question** by meaning, and score the match from 0 to 1:
   - **Strong match** (about 0.75 or more, or 0.65 or more with a clear winner): go straight ahead with no AI.
   - **Unsure** (0.50 to 0.75): the AI model chooses between the top 3 candidates, or says "none of these".
   - **Weak** (below 0.50): refuse politely and suggest example questions.
7. **Produce the answer:**
   - *Policy question* → the approved text from the Excel file, **word for word**.
   - *Personal data question* → read-only call to the HR system **with the employee's own badge**, then a fixed template builds the sentence and table.
8. **Return** the reply to the screen. Small grey text under each answer shows how it was decided (route, score, time) for transparency during the pilot.

### Worked examples

| The user types | What happens | Result |
|---|---|---|
| "What time does the office open?" | Strong match to FAQ-001. No AI used. About 5 ms. | Approved answer: office hours 9:00 to 18:00. |
| "Show my attendance last month" | Strong match to the attendance lookup. "Last month" is understood by simple rules. HR system called with the user's badge. | Summary sentence and a day-by-day table, plus a PDF button. |
| "Attendance two months ago" | Matches attendance. The rules cannot understand "two months ago", so the AI model is asked only to extract the month. Code (not the AI) works out which month that is. | August attendance. |
| "Can I work from home on Fridays?" | Unsure score (0.72). The AI chooses between candidates and picks the WFH policy. | Approved WFH policy text. |
| "Who won the world cup?" | Very weak match (about 0.2). | Polite refusal plus suggested questions. |
| "hi" | Recognised as a greeting. No AI. | Welcome message listing what the bot can do. |

## 6. How the bot is kept on-topic and safe (layers of protection)

Rather than trusting one instruction to the AI ("please only answer HR questions"), which clever users can sometimes bypass, we use **several independent layers**. A failure in one is caught by the next.

| Layer | Plain explanation |
|---|---|
| **1. Input filter** | Rejects empty or very long messages, known "trick the bot" phrases, and attempts to name another employee. Runs before any AI. |
| **2. Approved list only** | The bot can answer only from the Excel/JSON file or the four lookups. If nothing matches closely enough, it refuses. The AI does not decide what is in scope. The list does. |
| **3. Fixed answers** | Policy answers are copied from the file. Personal data is placed into templates. The AI **never writes** answer text, so it cannot invent policy or numbers. |
| **4. Constrained AI** | When the AI is used, it is forced to reply in a strict fill-in-the-blank format (for example "choose one of these 4 options"). It cannot write free text. |
| **5. Own data only** | The employee's own login token is used to call the HR system, so the HR system itself enforces "you may only see your data". The bot has no master key. |
| **6. Rate limits** | A user may have one question in progress at a time and a capped number per minute, which protects the server and blocks automated abuse. |
| **7. Safe fallback** | If the AI is slow or down, the bot still works for most questions. For unclear ones it says "Did you mean...?" with buttons. |

## 7. Where the answers come from

### a) The approved questions (Excel or JSON)
File: `data/faq.xlsx` (or `data/faq.json`). One row per question:

| id | category | question | variants | answer |
|---|---|---|---|---|
| FAQ-009 | Payroll | Where can I download my payslip? | how to get payslip; salary slip; view my payslip | Payslips are available in the HR portal under Payroll > My Payslips... |

*Variants* are other ways people phrase the same question. More variants mean better matching. **Editing and saving the file updates the bot within about 3 seconds**, with no restart and no developer.

### b) The rule catalogue ("one question, one action")
File: `data/catalogue.json` lists every question the bot can act on beyond the FAQ. It is organised **by question, not by topic**. Earlier, a single "leave" entry bundled
"apply", "balance" and "policy", so even a very specific question like "what's my leave balance" could only show a menu. Now each question is its own rule, so a
specific question gets a direct answer, and the menu appears **only** when someone types a bare topic such as "leave" or "holiday".

Each rule is labelled with a **mode** that decides how it behaves:

| Mode | What it is | What the user experiences | Examples |
|---|---|---|---|
| **A** | A question answered from HR data | A direct answer and a table, no clicking; asks a short follow-up only if something is missing (for example "Which month?") | leave balance, leave history, attendance, my holidays |
| **B** | Go to a page | A link card straight away | visitor pass, ID card, travel desk |
| **C** | Open an outside portal or do something that changes data | The bot first asks "Open the MyEquations Leave page in a new tab?" and waits for Yes or No | apply for leave, payslip, leave approvals (managers only) |
| **D** | Look something up in company content | Excerpts and links from the intranet, or a combined multi-office answer | leave policy, holidays across offices |
| **U** | Housekeeping | Greeting, help, "repeat that", "talk to a human" | hi, help, repeat |

Holiday questions come in **three flavours**, kept apart on purpose: *my* holidays (from the HR system, for my own office), holidays *across all offices* (compared in one table
from the intranet), and *one named office*. Words like "for me", "across offices" or "Chennai" decide which one applies. All HR calls are **read-only** and made with the
employee's own login:

| Lookup | HR system call (mock) | Remembered for |
|---|---|---|
| Attendance | `GET /attendance?month=YYYY-MM` or `?from=…&to=…` | 30 s |
| Leave balance | `GET /leave/balance` | 30 s |
| Leave history | `GET /leave/history?year=YYYY` | 30 s |
| Holidays (public and optional) | `GET /holidays?year=YYYY` | 24 h (holidays rarely change) |

**Spelling variants** (Deepavali = Diwali, CL = casual leave, Bombay = Mumbai) are kept in `data/dictionaries.json`. The same list feeds the search engine's synonym file
automatically, so the two never drift apart. When the bot cannot help, it offers to **send the question to HR support**, and keeps the unanswered question on a list that
catalogue editors use to add new rules.

### c) The company content (Solr, from Drupal)
Policies, guides and news pages written in Drupal are copied into **Solr**, the company's search engine. When a question is not an approved
FAQ or an HR lookup, the bot searches Solr (like a librarian searching the intranet) and shows the most relevant pages with a short
excerpt and a link. It does **not** rewrite or summarise: it only shows words that exist on an indexed page. A result must pass **two
checks**: the page must contain the question's key words, **and** its meaning must be close to what was asked (so "programming language"
does not return the "Referral **Program**" page). If nothing passes, the bot refuses as usual. In this proof of concept Solr holds 12 sample pages
in `data/solr/content.json`.

### d) The HR system
The real HR APIs are replaced here by `mock-hr/`, which generates stable fake data per employee (five demo employees plus synthetic ones for load testing). Switching to the real system means changing one setting (`HR_API_URL`) and making sure the real system accepts the employee's login token.

## 8. The AI model

- **What it is:** a small open-source language model (Qwen2.5 1.5B, compressed to about 1 GB) served by *llama.cpp*, which is efficient on ordinary CPUs. It runs on our server and never contacts the internet after the first download.
- **Its only two jobs:**
  1. *Tie-breaker:* when the match is unsure, pick the best of 3 candidates or "none".
  2. *Understand vague dates/filters:* turn "two months ago" or "my sick leaves last year" into month, year and leave type. Simple rules handle the easy cases first, so the AI is called only when they cannot.
- **What it can never do:** write answers, see other employees' data, call the HR system itself, or answer off-topic questions.
- **If it is busy:** each AI call waits at most 4 seconds for a free slot. If there is no slot, the bot falls back to simple rules or shows "Did you mean...?" buttons rather than making the user wait.
- **Model size:** the 1.5B model was chosen so the proof of concept runs on a laptop. On the 64-core production server we would use a larger 3 to 8 billion parameter model (still about 3 to 5 GB of the 32 GB) for better wording understanding. This is a single setting (`LLM_MODEL`).

## 9. Serving 250 people on one server

**The key insight:** 250 registered users is not 250 people typing at the same instant. Realistically 10 to 25 are active at once. And because most questions never use the AI, most replies are instant.

How the design handles load:

| Technique | Plain explanation |
|---|---|
| **Fast path first** | Most questions are answered by matching and simple lookups in milliseconds. |
| **Limited AI slots** | The AI serves 4 requests at the same time (continuous batching). Others wait briefly (up to 4 s), then fall back to a simpler method. |
| **Caching** | Recently fetched HR data is remembered for a short time (30 s; holidays 24 h), reducing calls to the HR system. |
| **Per-user limits** | One request at a time per person; a maximum per minute. |
| **Easy to copy** | More gateway copies can be added behind a load balancer if needed (production would move rate limits and caches to Redis). |

### Load-test result (proof of concept)
We simulated **250 users** for 2 minutes, each asking a question every 8 to 28 seconds (about 10 requests per second, much heavier than real life), on a **laptop** with the small model:

| Measure | Result |
|---|---|
| Total questions answered | 1,513 |
| Errors | **0** |
| Typical (median) response time | **85 milliseconds** |
| 95% of responses faster than | **5.9 seconds** |
| Share of questions that needed the AI | 14% |

*How to read this:* most people get an answer almost instantly. The slower ones are the minority that needed the AI. A first test without the 4-second wait cap produced timeouts, which is why that protection exists. **These numbers come from a laptop, not the real server**, so the load test must be repeated on the 64-core machine before capacity promises are made (the script is `loadtest/k6.js`). The PDF and greeting features were added after this test and have not been re-measured.

## 10. Security and privacy

- **Stays on-premises:** the AI, search and all data processing run on company servers. Nothing is sent to external AI services. (Models are downloaded once at first start.)
- **Identity:** every request carries the employee's login token. No token, or an invalid one, means no answer.
- **Own data only:** data is fetched with the employee's own token, so the HR system's rules apply. Messages that name another employee are refused.
- **No write access:** the four lookups are read-only.
- **Prompt-injection defence:** attempts like "ignore previous instructions" are blocked, and the AI has no tools, no secrets and no free-text output.
- **PDF downloads:** the token is sent in a request header (never in a web address, which could be logged or shared), and the only options accepted are from a fixed list.
- **Auditing:** each answer records which route was used, the match score and the time. Storing a permanent audit trail is a production task.

## 11. Greeting message and PDF download

### Greeting
Typing *hi, hello, hey, good morning, help, menu* or *what can you do* shows a welcome message that:
- greets the employee by first name,
- lists what the bot can do (attendance, leave balance, leave history, public holidays, company FAQs by category, PDF downloads),
- states that it answers only approved questions and only about the user's own data,
- offers clickable example questions.

It is recognised by a simple pattern, with no AI, so it appears instantly.

### PDF download
Any table (attendance, leave balance, leave history, holidays) can be downloaded as a PDF in two ways:
1. **Button:** a "Download PDF" button under every table.
2. **Just ask:** "give me this in pdf", "attendance for August as pdf", "public holidays in a pdf file", or "last year in pdf" after a leave history. The bot remembers the last table you saw, so "this" works. If it is ambiguous (just "pdf"), it asks which report you want. Policy answers are text-only and are not exportable.

**What happens behind the scenes:** the chat reply includes a small "recipe" (which report, which month/year). The screen sends that recipe to a PDF endpoint, the gateway fetches the data again with the user's own token, draws an A4 report (title, employee name/ID/department, summary line, striped table, page numbers) and the browser saves the file.

## 12. Technology choices

| Technology | Role | Why |
|---|---|---|
| **React** | Chat screen | Already used by the company website, so the widget can be embedded in it. |
| **NestJS (Node.js)** | Gateway | Already used by the company. Same team, skills and deployment. No Python needed. |
| **llama.cpp** | Runs the AI model | Efficient on CPUs without a graphics card; simple to run; can force the output into a strict format. |
| **Qwen2.5 (GGUF, 4-bit)** | The AI model | Small, open-source, runs offline, good at following instructions. Swappable via a setting. |
| **MiniLM embeddings** | Matches meaning | Tiny (about 25 MB) and fast on CPU. If it cannot load, a keyword-matching fallback takes over. |
| **Excel / JSON** | Approved questions | HR can edit it directly; no database needed. |
| **PDFKit** | PDF reports | Generates PDFs inside the gateway; no extra service. |
| **Docker Compose** | Packaging | One command starts all parts; the same on a laptop or the server. |
| **k6** | Load testing | Simulates hundreds of users to measure speed and errors. |

## 13. Known limitations (proof of concept)

- **Mock HR data and mock content:** results are realistic but fake. The real HR APIs and the real Drupal/Solr index must be connected and the relevance thresholds re-tuned on real pages.
- **Content search is keyword-based plus a meaning filter:** very differently worded questions can be missed; it also does not yet check who may read a page.
- **Login:** a demo token lookup stands in for real company single sign-on; it must be replaced.
- **Small AI model:** a 1.5B model occasionally needs the "Did you mean...?" fallback. A larger one on the production server improves this.
- **Single copy:** caches, limits and the AI queue are held in the gateway's memory. For several gateway copies, move them to Redis.
- **Answers appear all at once:** no word-by-word streaming (answers are short and templated).
- **Language:** tested in English only. Other languages need a multilingual matching model.
- **Short memory:** the bot remembers only the last table (for "this in pdf" and "and for August?"), not a long conversation.
- **Capacity numbers are from a laptop:** see section 9.

## 14. Roadmap

| Phase | What | Outcome |
|---|---|---|
| **A. Measure on the real server** | Run the load test on the 64-core box; compare 3 to 8 billion parameter models; tune CPU threads and slots (possibly 2 to 4 AI instances, one per processor group). | Chosen model and proven capacity. |
| **B. Production hardening** | Real login/SSO, real HR APIs, Redis for shared limits and cache, audit logging, monitoring dashboards (queue length, speed, refusal rate), automated safety tests with tricky questions. | A system ready for pilot users. |
| **C. Solr and Drupal content** | A new "search company content" lookup: search Drupal pages through Solr, return the best 3 passages, and summarise **only those passages** with links to the source. If nothing relevant is found, refuse. | The bot can answer from intranet content without leaving its guardrails. |
| **C. Solr and Drupal content** | **Proof of concept done:** a Solr index with Drupal-style pages is searched when a question is not an FAQ or HR lookup; the bot shows excerpts and links, and refuses if nothing relevant is found. **Still to do:** connect the real Drupal/Solr index, split long pages into passages, add dense-vector (meaning-based) search, and respect who is allowed to read each page. | The bot answers from intranet content without leaving its guardrails. |

## 15. Glossary

| Term | Meaning |
|---|---|
| **LLM (language model)** | A program trained on lots of text that can read and write sentences. Here it is small and used only as a helper. |
| **On-premises (on-prem)** | Running on the company's own servers, not in someone else's cloud. |
| **Guardrails** | Rules that keep the bot inside its approved topics. |
| **Embedding** | A list of numbers that captures the meaning of a sentence, so similar sentences get similar numbers. |
| **Match score** | How similar a question is to an approved one (0 = unrelated, 1 = identical). |
| **Intent** | The kind of thing the user wants (for example "show my leave balance"). |
| **API** | A way for one program to ask another for information. The HR system provides APIs. |
| **Token (login token)** | A digital ID badge proving who the user is. |
| **Prompt injection** | Tricking an AI with phrases like "ignore your rules". |
| **Rate limit** | A cap on how many requests one person can make per minute. |
| **Cache** | A short-term memory of recent results to avoid repeated work. |
| **Latency / p95** | Response time. "p95 of 5.9 s" means 95% of answers arrived faster than 5.9 seconds. |
| **Docker** | A way of packaging software into sealed boxes that run the same everywhere. |
| **CPU vs GPU** | The normal processor vs a graphics card. AI is usually run on GPUs. We deliberately run on CPU only. |
| **Quantization (Q4)** | Compressing the model so it uses far less memory with little quality loss. |
| **Solr / Drupal** | The company's search engine and content management system, to be connected in phase C. |
