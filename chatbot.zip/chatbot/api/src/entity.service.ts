import { Injectable, Logger } from '@nestjs/common';
import { config } from './config';
import { KnowledgeService } from './knowledge.service';
import { LlmService } from './llm.service';
import { LeaveType, Params } from './tools.service';

const MONTH_NAMES = ['january', 'february', 'march', 'april', 'may', 'june', 'july', 'august', 'september', 'october', 'november', 'december'];
const MONTH_RE = new RegExp(`\\b(${MONTH_NAMES.join('|')}|jan|feb|mar|apr|jun|jul|aug|sept?|oct|nov|dec)\\b`, 'gi');
const NUM_WORDS: Record<string, number> = { a: 1, an: 1, one: 1, two: 2, three: 3, four: 4, five: 5, six: 6, seven: 7, eight: 8, nine: 9, ten: 10, eleven: 11, twelve: 12 };
const NUM = '(\\d{1,3}|a|an|one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve)';
// time-ish words the deterministic rules did not consume: only then is the LLM worth calling
const HINT_RE = /\b(last|next|previous|prev|ago|year|month|week|today|yesterday|tomorrow|20\d\d|jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)/i;

const PARAM_SCHEMA = {
  type: 'object',
  properties: {
    month: { type: 'integer', minimum: 0, maximum: 12 },
    year: { type: 'integer', minimum: 0, maximum: 2100 },
    relative: { type: 'string', enum: ['none', 'this_month', 'last_month', 'this_year', 'last_year', 'next_year'] },
    leave_type: { type: 'string', enum: ['any', 'annual', 'sick', 'casual'] },
    upcoming: { type: 'boolean' },
  },
  required: ['month', 'year', 'relative', 'leave_type', 'upcoming'],
  additionalProperties: false,
};

const iso = (d: Date) => d.toISOString().slice(0, 10);
const utc = (y: number, m: number, d: number) => new Date(Date.UTC(y, m, d));
const addDays = (d: Date, n: number) => new Date(d.getTime() + n * 86400000);
const monthIndex = (s: string) => MONTH_NAMES.findIndex((x) => x.startsWith(s.toLowerCase().slice(0, 3)));
const toNum = (s: string) => (/^\d+$/.test(s) ? Number(s) : NUM_WORDS[s.toLowerCase()]);

/** "5 nov", "nov 5", "5th november 2026", "2026-11-05" -> ISO date (year defaults to the current year) */
export function parseDateExpr(s: string, defaultYear: number): string | undefined {
  const t = s.trim().toLowerCase().replace(/(\d)(st|nd|rd|th)\b/g, '$1');
  let m = t.match(/\b(\d{4})-(\d{2})-(\d{2})\b/);
  if (m) return `${m[1]}-${m[2]}-${m[3]}`;
  m = t.match(new RegExp(`\\b(\\d{1,2})\\s+(${MONTH_NAMES.join('|')}|jan|feb|mar|apr|jun|jul|aug|sept?|oct|nov|dec)\\b(?:\\s+(20\\d\\d))?`));
  if (m) return iso(utc(Number(m[3] ?? defaultYear), monthIndex(m[2]), Number(m[1])));
  m = t.match(new RegExp(`\\b(${MONTH_NAMES.join('|')}|jan|feb|mar|apr|jun|jul|aug|sept?|oct|nov|dec)\\s+(\\d{1,2})\\b(?:\\s+(20\\d\\d))?`));
  if (m) return iso(utc(Number(m[3] ?? defaultYear), monthIndex(m[1]), Number(m[2])));
  return undefined;
}

@Injectable()
export class EntityService {
  private log = new Logger('Entities');
  constructor(private kb: KnowledgeService, private llm: LlmService) {}

  /** Deterministic extraction (regex + dictionaries); the LLM is a last resort for unexplained time words. */
  async extract(text: string, ruleId: string, state: { llmUsed: boolean }): Promise<Params> {
    const { p, rest } = this.deterministic(text, ruleId);
    const resolved = !!(p.month || p.from || p.year);
    if (!resolved && config.useLlm && HINT_RE.test(rest)) {
      try {
        state.llmUsed = true;
        const o = await this.llm.json<any>(
          `Extract filters from an employee's HR question. Today is ${iso(new Date())}. Use 0 for unknown month/year, "none" for no relative period, "any" for no leave type. Do not guess.`,
          `Question: """${text}"""`, PARAM_SCHEMA, 60,
        );
        const lp = this.fromLlm(o);
        for (const [k, v] of Object.entries(lp)) if ((p as any)[k] === undefined) (p as any)[k] = v;
      } catch (e: any) {
        this.log.warn(`LLM extraction unavailable, deterministic only: ${e?.message}`);
      }
    }
    return this.finish(p, ruleId);
  }

  /** Just the deterministic part: used when the answer to a clarifying question is a single word/phrase. */
  extractQuick(text: string, ruleId: string): Params { return this.finish(this.deterministic(text, ruleId).p, ruleId); }

  private finish(p: Params, ruleId: string): Params {
    const now = new Date();
    if (ruleId === 'attendance_summary' && p.month && p.year === undefined) {
      p.year = p.month > now.getUTCMonth() + 1 ? now.getUTCFullYear() - 1 : now.getUTCFullYear();
    }
    if (p.month && ruleId.startsWith('holiday')) p.upcoming = false;
    for (const k of Object.keys(p)) if ((p as any)[k] === undefined) delete (p as any)[k];
    return p;
  }

  private deterministic(text: string, ruleId: string): { p: Params; rest: string } {
    const now = new Date();
    const today = utc(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate());
    const cy = today.getUTCFullYear(); const cm = today.getUTCMonth() + 1;
    const p: Params = {};
    let rest = text;
    const take = (re: RegExp) => { const m = rest.match(re); if (m) rest = rest.replace(re, ' '); return m; };
    const isAttendance = ruleId === 'attendance_summary';
    const isHoliday = ruleId.startsWith('holiday');

    // 1. explicit range: "between 1 jan and 31 jan", "from 5 oct to 9 oct"
    const rng = take(/\b(?:between|from)\s+(.+?)\s+(?:and|to|till|until|through)\s+(.+?)(?=$|[?.!,]|\s+(?:for|in|please)\b)/i);
    if (rng) {
      const a = parseDateExpr(rng[1], cy); const b = parseDateExpr(rng[2], cy);
      if (a && b) { p.from = a <= b ? a : b; p.to = a <= b ? b : a; } else rest += ` ${rng[0]}`;
    }

    // 2. rolling windows: "last 7 days", "past 2 weeks", "last week", "this week"
    if (!p.from) {
      const w = take(new RegExp(`\\b(?:last|past|previous)\\s+${NUM}\\s+(days?|weeks?)\\b`, 'i'));
      if (w) {
        const n = toNum(w[1]) ?? 1; const days = /week/i.test(w[2]) ? n * 7 : n;
        p.to = iso(today); p.from = iso(addDays(today, -(days - 1)));
      } else if (take(/\b(?:last|previous) week\b/i)) {
        const dow = (today.getUTCDay() + 6) % 7; // Monday = 0
        const mon = addDays(today, -dow - 7);
        p.from = iso(mon); p.to = iso(addDays(mon, 6));
      } else if (take(/\bthis week\b/i)) {
        const dow = (today.getUTCDay() + 6) % 7;
        p.from = iso(addDays(today, -dow)); p.to = iso(today);
      } else if (take(/\b(?:past|last) week\b/i)) { p.to = iso(today); p.from = iso(addDays(today, -6)); }
    }

    // 3. N months ago / relative months
    if (!p.from) {
      const ago = take(new RegExp(`\\b${NUM}\\s+months?\\s+ago\\b`, 'i'));
      if (ago) {
        const n = toNum(ago[1]) ?? 1; const d = utc(cy, cm - 1 - n, 1);
        p.month = d.getUTCMonth() + 1; p.year = d.getUTCFullYear();
      } else if (take(/\b(?:last|previous) month\b/i)) {
        p.month = cm === 1 ? 12 : cm - 1; p.year = cm === 1 ? cy - 1 : cy;
      } else if (take(/\bthis month\b/i)) { p.month = cm; p.year = cy; }
      else if (take(/\bnext month\b/i)) { p.month = cm === 12 ? 1 : cm + 1; p.year = cm === 12 ? cy + 1 : cy; }
    }

    // 4. month names (the verb "may" only counts after a preposition or before a day/year)
    if (!p.from && !p.month) {
      for (const m of rest.matchAll(MONTH_RE)) {
        const word = m[1].toLowerCase();
        if (word === 'may' && !/\b(in|of|for|during|from|on|since|until)\s+may\b|\bmay\s+(\d{1,2}|20\d\d)\b/i.test(rest)) continue;
        p.month = monthIndex(word) + 1;
        rest = rest.replace(m[0], ' ');
        break;
      }
    }

    // 5. years
    const y = take(/\b(20\d\d)\b/);
    if (y) p.year = Number(y[1]);
    if (take(/\b(?:last|previous) year\b/i)) p.year = cy - 1;
    else if (take(/\bnext year\b/i)) p.year = cy + 1;
    else if (take(/\bthis year\b/i)) p.year = cy;

    // 6. today / tomorrow / yesterday
    if (isAttendance && !p.from) {
      if (take(/\byesterday\b/i)) { p.from = p.to = iso(addDays(today, -1)); }
      else if (take(/\btoday\b/i)) { p.from = p.to = iso(today); }
    }
    if (isHoliday) {
      const rd = take(/\b(today|tomorrow)\b/i);
      if (rd) p.relDay = rd[1].toLowerCase() as 'today' | 'tomorrow';
    }

    // 7. dictionary entities and flags
    const lt = this.kb.findInDictionary(text, 'quotaTypes');
    if (lt && ['annual', 'sick', 'casual'].includes(lt)) p.leaveType = lt as LeaveType;
    const hn = this.kb.findInDictionary(text, 'holidayNames');
    if (hn && isHoliday) p.holidayName = hn;
    const off = this.kb.findInDictionary(text, 'offices');
    if (off) p.office = off;
    if (/\b(optional|restricted)\b/i.test(text)) p.holidayType = 'optional';
    else if (/\bpublic\b/i.test(text)) p.holidayType = 'public';
    if (/\blong weekends?\b/i.test(text)) p.longWeekend = true;
    if (/\b(next|upcoming)\b/i.test(text) && !/\bnext (year|month|week)\b/i.test(text)) p.upcoming = true;
    const st = text.match(/\b(pending|approved|rejected)\b/i);
    if (st) p.status = st[1].toLowerCase();
    return { p, rest };
  }

  private fromLlm(o: any): Params {
    const n = new Date(); const cy = n.getUTCFullYear(); const cm = n.getUTCMonth() + 1;
    const p: Params = {};
    if (o.month >= 1 && o.month <= 12) p.month = o.month;
    if (o.year >= 2000) p.year = o.year;
    switch (o.relative) {
      case 'this_month': p.month = cm; p.year = cy; break;
      case 'last_month': p.month = cm === 1 ? 12 : cm - 1; p.year = cm === 1 ? cy - 1 : cy; break;
      case 'this_year': p.year = cy; break;
      case 'last_year': p.year = cy - 1; break;
      case 'next_year': p.year = cy + 1; break;
    }
    if (['annual', 'sick', 'casual'].includes(o.leave_type)) p.leaveType = o.leave_type as LeaveType;
    return p;
  }
}
