/**
 * Rule catalogue model. One rule = one distinct question = (ideally) one action, so a specific query
 * resolves directly; only a bare domain word ("leave") shows the domain menu.
 *
 * Modes: A conversational data query (api_view, no confirm) · B navigation (intranet_page, direct link)
 *        C external portal / write (confirm first)           · D content lookup (Solr)
 *        U utility (greeting/help/repeat/escalate: matched exactly, never semantically)
 */
export type Mode = 'A' | 'B' | 'C' | 'D' | 'U';
export type RuleType = 'api_view' | 'api_action' | 'portal' | 'intranet_page' | 'drupal_search' | 'pdf' | 'utility';

export interface EntityDef {
  name: string;
  label: string;
  type: 'period' | 'select' | 'text';
  required?: boolean;
  prompt?: string;
  options?: string[];
  dictionary?: 'holidayNames' | 'quotaTypes' | 'offices';
}

export interface Rule {
  id: string;
  domain?: string;
  mode: Mode;
  type: RuleType;
  searchTerm: string;
  label: string;
  aliases: string[];
  keywords?: string[];
  sampleUtterances: string[];
  entities?: EntityDef[];
  roles?: string[];
  confirmMessage?: string;
  target?: { base: 'myequations' | 'intranet'; path: string; title: string; description?: string };
  apiMethodKey?: string;
  searchQuery?: string;
  exportable?: boolean;
  searchable?: boolean; // false = exact match only (utility rules)
  priority?: number;
  active?: boolean;
}

export interface Domain { id: string; label: string; aliases: string[]; menuPrompt: string; options: string[] }

export interface Dictionaries {
  holidayNames: Record<string, string[]>;
  quotaTypes: Record<string, string[]>;
  offices: Record<string, string[]>;
}

/** What the client echoes back so the server can stay stateless between turns. */
export interface Pending {
  type: 'confirm' | 'entity';
  ruleId: string;
  params?: Record<string, any>;
  ask?: string;
  tries?: number;
}
