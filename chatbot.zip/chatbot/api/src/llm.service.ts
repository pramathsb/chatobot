import { Injectable, Logger } from '@nestjs/common';
import { config } from './config';

export class BusyError extends Error {}

/**
 * Thin client for llama.cpp's OpenAI-compatible server.
 * - semaphore keeps in-flight calls <= llama-server slots, extra requests wait in a bounded queue
 * - responses are constrained to a JSON schema (grammar-based), so the model cannot free-write
 */
@Injectable()
export class LlmService {
  private log = new Logger('LLM');
  private inflight = 0;
  private waiters: Array<{ wake: () => void }> = [];

  get stats() { return { inflight: this.inflight, queued: this.waiters.length }; }

  async healthy(): Promise<boolean> {
    try {
      const r = await fetch(`${config.llmUrl}/health`, { signal: AbortSignal.timeout(2000) });
      return r.ok;
    } catch { return false; }
  }

  private async acquire() {
    if (this.inflight < config.llmConcurrency) { this.inflight++; return; }
    if (this.waiters.length >= config.llmQueueMax) throw new BusyError('LLM queue full');
    // bounded wait: if the LLM is saturated, shed the call so the caller can degrade instead of stalling
    await new Promise<void>((resolve, reject) => {
      const w = {
        wake: () => { clearTimeout(timer); resolve(); },
      };
      const timer = setTimeout(() => {
        this.waiters = this.waiters.filter((x) => x !== w);
        reject(new BusyError('LLM queue wait exceeded'));
      }, config.llmQueueWaitMs);
      this.waiters.push(w);
    });
  }
  private release() {
    const next = this.waiters.shift();
    if (next) next.wake(); else this.inflight--;
  }

  async json<T>(system: string, user: string, schema: object, maxTokens = 64): Promise<T> {
    await this.acquire();
    try {
      const r = await fetch(`${config.llmUrl}/v1/chat/completions`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        signal: AbortSignal.timeout(config.llmTimeoutMs),
        body: JSON.stringify({
          model: 'local',
          temperature: 0,
          max_tokens: maxTokens,
          messages: [{ role: 'system', content: system }, { role: 'user', content: user }],
          response_format: { type: 'json_schema', json_schema: { name: 'out', strict: true, schema } },
        }),
      });
      if (!r.ok) throw new Error(`llm http ${r.status}: ${(await r.text()).slice(0, 200)}`);
      const body: any = await r.json();
      return JSON.parse(body.choices[0].message.content) as T;
    } finally {
      this.release();
    }
  }
}
