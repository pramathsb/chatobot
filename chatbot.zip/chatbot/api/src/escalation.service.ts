import { Injectable, Logger } from '@nestjs/common';
import * as fs from 'fs';
import * as path from 'path';
import { config } from './config';
import { normalizeExact } from './knowledge.service';

/**
 * Two records are written from the same event but serve different audiences:
 *  - escalations.jsonl      user-facing: a support request someone follows up on (stands in for the email/notification to HR)
 *  - candidate_rules.jsonl  catalogue backlog: queries the catalogue could not answer, for editors to turn into rules/FAQs
 */
@Injectable()
export class EscalationService {
  private log = new Logger('Escalation');

  async record(e: { userId: string; name: string; query: string; correlationId: string; note?: string }): Promise<{ ticketId: string }> {
    const ticketId = `ESC-${Date.now().toString(36).toUpperCase()}`;
    const ts = new Date().toISOString();
    const query = e.query.slice(0, config.maxMessageLen);
    const append = (file: string, obj: object) => fs.promises.appendFile(path.join(config.dataDir, file), JSON.stringify(obj) + '\n');
    try {
      await append('escalations.jsonl', { ts, ticketId, userId: e.userId, name: e.name, query, correlationId: e.correlationId, note: (e.note || '').slice(0, 500), status: 'open' });
      await append('candidate_rules.jsonl', { ts, normalizedQuery: normalizeExact(query), sampleQuery: query, correlationId: e.correlationId, ticketId });
    } catch (err: any) {
      this.log.error(`could not persist escalation: ${err?.message}`);
      throw err;
    }
    this.log.log(`${ticketId} from ${e.userId}: "${query}"`);
    return { ticketId };
  }
}
