import { Module } from '@nestjs/common';
import { ChatController } from './chat.controller';
import { ChatService } from './chat.service';
import { EmbeddingService } from './embedding.service';
import { EntityService } from './entity.service';
import { EscalationService } from './escalation.service';
import { ExecutorService } from './executor.service';
import { GuardService } from './guard.service';
import { HolidayAggregationFormatter } from './holiday-aggregation.formatter';
import { KnowledgeService } from './knowledge.service';
import { LlmService } from './llm.service';
import { PdfService } from './pdf.service';
import { SolrService } from './solr.service';
import { ToolsService } from './tools.service';

@Module({
  controllers: [ChatController],
  providers: [
    ChatService, EmbeddingService, EntityService, EscalationService, ExecutorService, GuardService,
    HolidayAggregationFormatter, KnowledgeService, LlmService, PdfService, SolrService, ToolsService,
  ],
})
export class AppModule {}
