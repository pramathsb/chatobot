import { Injectable } from '@nestjs/common';
import { HolidayDoc } from './solr.service';
import { MONTHS, ToolResult } from './tools.service';

const short = (iso: string) => { const d = new Date(`${iso}T00:00:00Z`); return `${d.getUTCDate()} ${MONTHS[d.getUTCMonth()].slice(0, 3)}`; };
const long = (iso: string) => {
  const d = new Date(`${iso}T00:00:00Z`);
  return `${['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'][d.getUTCDay()]}, ${d.getUTCDate()} ${MONTHS[d.getUTCMonth()].slice(0, 3)} ${d.getUTCFullYear()}`;
};
const dayOf = (iso: string) => ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'][new Date(`${iso}T00:00:00Z`).getUTCDay()];

/**
 * Grouped aggregation of per-office holiday documents. Different from the single top-result summary used by
 * ordinary content search: the answer is built by grouping every matching document by office / holiday.
 */
@Injectable()
export class HolidayAggregationFormatter {
  format(docs: HolidayDoc[], opts: { office?: string; holidayName?: string }): ToolResult {
    const year = docs[0]?.date.slice(0, 4) ?? String(new Date().getUTCFullYear());

    // one specific holiday
    if (opts.holidayName) {
      const name = opts.holidayName;
      if (!docs.length) {
        return { title: `${name} - ${year}`, reply: opts.office ? `${name} is not listed in the ${opts.office} office holiday calendar.` : `No office holiday calendar lists ${name}.` };
      }
      if (opts.office) {
        const d = docs[0];
        return { title: `${name} - ${opts.office}`, reply: `Yes, ${name} is a holiday at the ${opts.office} office on ${long(d.date)}.`, table: { columns: ['Office', 'Date', 'Day'], rows: [[d.office, d.date, dayOf(d.date)]] } };
      }
      const same = docs.every((d) => d.date === docs[0].date);
      const line = same
        ? `${name} is on ${long(docs[0].date)} at all ${docs.length} offices (${docs.map((d) => d.office).join(', ')}).`
        : `${name}: ${docs.map((d) => `${d.office} — ${short(d.date)}`).join(', ')}.`;
      return { title: `${name} across offices - ${year}`, reply: line, table: { columns: ['Office', 'Date', 'Day'], rows: docs.map((d) => [d.office, d.date, dayOf(d.date)]) } };
    }

    // one office, full list
    if (opts.office) {
      if (!docs.length) return { title: `Holidays - ${opts.office}`, reply: `I could not find a holiday calendar for the ${opts.office} office.` };
      return {
        title: `Holiday Calendar - ${opts.office} - ${year}`,
        reply: `The ${opts.office} office has ${docs.length} holidays in ${year}.`,
        table: { columns: ['Date', 'Day', 'Holiday'], rows: docs.map((d) => [d.date, dayOf(d.date), d.name]) },
      };
    }

    // all offices: pivot of holiday x office, plus a plain-language note on where offices differ
    if (!docs.length) return { title: 'Holidays across offices', reply: 'I could not find any office holiday calendars.' };
    const offices = [...new Set(docs.map((d) => d.office))].sort();
    const byHoliday = new Map<string, Map<string, string>>();
    for (const d of docs) {
      if (!byHoliday.has(d.name)) byHoliday.set(d.name, new Map());
      byHoliday.get(d.name)!.set(d.office, d.date);
    }
    const ordered = [...byHoliday.entries()].sort((a, b) => [...a[1].values()].sort()[0].localeCompare([...b[1].values()].sort()[0]));
    const notes: string[] = [];
    for (const [name, m] of ordered) {
      if (m.size < offices.length) notes.push(`${name} (${[...m.keys()].join(', ')} only)`);
      else if (new Set(m.values()).size > 1) notes.push(`${name} differs by office`);
    }
    return {
      title: `Holidays across offices - ${year}`,
      reply: `Holiday calendar across ${offices.length} offices (${offices.join(', ')}): ${byHoliday.size} holidays in ${year}.` + (notes.length ? ` Not the same everywhere: ${notes.join('; ')}.` : ' All offices follow the same calendar.'),
      table: { columns: ['Holiday', ...offices], rows: ordered.map(([name, m]) => [name, ...offices.map((o) => (m.has(o) ? short(m.get(o)!) : '-'))]) },
    };
  }
}
