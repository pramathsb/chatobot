import { Injectable } from '@nestjs/common';
import { Rule } from './catalogue';
import { config } from './config';
import { HolidayAggregationFormatter } from './holiday-aggregation.formatter';
import { SolrService } from './solr.service';
import { Params, ToolResult, ToolsService } from './tools.service';

export class MissingEntityError extends Error { constructor(public entity: string) { super(`missing entity ${entity}`); } }

/** Runs a rule's action. Shared by the chat flow and the PDF export endpoint so both produce identical data. */
@Injectable()
export class ExecutorService {
  constructor(private tools: ToolsService, private solr: SolrService, private holidays: HolidayAggregationFormatter) {}

  /** Mode A (HR API) and structured Mode D (Solr holiday calendar) rules that produce a table. */
  async run(rule: Rule, token: string, p: Params): Promise<ToolResult> {
    const key = rule.apiMethodKey;
    if (!key) throw new Error(`rule ${rule.id} has no apiMethodKey`);
    if (this.tools.has(key)) return this.tools.run(key, token, p);
    if (key === 'holiday_calendar_all') {
      return this.holidays.format(await this.solr.holidayDocs({ holidayName: p.holidayName }), { holidayName: p.holidayName });
    }
    if (key === 'holiday_calendar_office') {
      if (!p.office) throw new MissingEntityError('office');
      return this.holidays.format(await this.solr.holidayDocs({ office: p.office, holidayName: p.holidayName }), { office: p.office, holidayName: p.holidayName });
    }
    throw new Error(`unknown apiMethodKey ${key}`);
  }

  /** Mode B / C target as an absolute link. */
  link(rule: Rule): { title: string; url: string; description?: string } {
    const t = rule.target;
    if (!t) throw new Error(`rule ${rule.id} has no target`);
    const base = t.base === 'myequations' ? config.myequationsBaseUrl : config.intranetBaseUrl;
    return { title: t.title, url: `${base}${t.path}`, description: t.description };
  }
}
