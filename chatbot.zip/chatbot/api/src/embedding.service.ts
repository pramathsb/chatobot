import { Injectable, Logger } from '@nestjs/common';
import { config } from './config';

/**
 * Local sentence embeddings (MiniLM via ONNX, runs on CPU inside the api container).
 * If the model cannot be loaded (e.g. no internet on first start), ready resolves false and
 * the knowledge service falls back to lexical matching.
 */
@Injectable()
export class EmbeddingService {
  private log = new Logger('Embedding');
  private pipe: any = null;
  private readyP: Promise<boolean>;

  constructor() {
    this.readyP = this.init();
  }

  whenReady() { return this.readyP; }
  get available() { return !!this.pipe; }

  private async init(): Promise<boolean> {
    try {
      // @huggingface/transformers is ESM-only; keep a real dynamic import under CommonJS output
      const dynImport = new Function('m', 'return import(m)');
      const { pipeline, env } = await dynImport('@huggingface/transformers');
      env.cacheDir = config.modelCache;
      this.pipe = await pipeline('feature-extraction', 'Xenova/all-MiniLM-L6-v2', { dtype: 'q8' });
      this.log.log('embedding model ready');
      return true;
    } catch (e: any) {
      this.log.warn(`embedding model unavailable, using lexical matching: ${e?.message}`);
      return false;
    }
  }

  async embed(text: string): Promise<Float32Array> {
    const out = await this.pipe(text, { pooling: 'mean', normalize: true });
    return out.data as Float32Array;
  }
}
