import { Injectable, Logger } from '@nestjs/common';
import { randomUUID } from 'crypto';
import { Pending, Rule } from './catalogue';
import { config } from './config';
import { EntityService } from './entity.service';
import { ExecutorService, MissingEntityError } from './executor.service';
import { GuardService } from './guard.service';
import { Candidate, KnowledgeService } from './knowledge.service';
import { BusyError, LlmService } from './llm.service';
import { SolrService } from './solr.service';
import { AuthError, Me, Params, ToolResult, ToolsService, UpstreamError } from './tools.service';

export interface ChatContext { lastIntent?: string; lastParams?: Params; lastReply?: string; lastQuery?: string; pending?: Pending }
export interface ExportRef { intent: string; params: Params }
export interface ChatReply {
  reply: string;
  source: 'faq' | 'tool' | 'clarify' | 'refusal' | 'error' | 'greeting' | 'content' | 'menu' | 'confirm' | 'link' | 'info';
  correlationId?: string;
  intent?: string | null;
  params?: Params;
  table?: ToolResult['table'];
  sources?: Array<{ title: string; url: string; type: string; snippet: string; updated?: string; relevance?: number }>;
  link?: { title: string; url: string; description?: string };
  confirm?: { ruleId: string };
  pending?: Pending;
  escalate?: { query: string };
  export?: ExportRef;
  autoDownload?: boolean;
  suggestions?: string[];
  debug: { route: string; mode?: string; score?: number; ms: number; llmUsed: boolean; semantic: boolean; guard?: string };
}
type Reply = Omit<ChatReply, 'debug' | 'correlationId'>;
type State = { llmUsed: boolean };

const PDF_RE = /\bpdf\b|\bexport\b|\bdownload\b.*\b(report|table|attendance|leave|holiday|holidays|balance|history|calendar|this|that|it)\b/i;
const YES_RE = /^\s*(yes|y|yeah|yep|sure|ok|okay|open|open it|confirm|go ahead|please do)[\s!.]*$/i;
const NO_RE = /^\s*(no|n|nope|cancel|not now|dont|don't|stop)[\s!.]*$/i;
const HOLIDAY_ALL_RE = /\b(across|all (the )?(offices|locations|sites)|compar\w+|each office|every office|which offices)\b/i;
const FOLLOWUP_RE = /\b(last|next|previous|prev|ago|year|month|week|today|yesterday|20\d\d|sick|casual|annual|jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)/i;

@Injectable()
export class ChatService {
  private log = new Logger('Chat');

  constructor(
    private kb: KnowledgeService,
    private llm: LlmService,
    private guard: GuardService,
    private tools: ToolsService,
    private solr: SolrService,
    private entities: EntityService,
    private exec: ExecutorService,
  ) {}

  async handle(token: string, message: string, ctx: ChatContext = {}): Promise<ChatReply> {
    const t0 = Date.now();
    const state: State = { llmUsed: false };
    const correlationId = randomUUID().slice(0, 8);
    let mode: string | undefined;
    const done = (r: Reply, route: string, score?: number, guard?: string): ChatReply => ({
      ...r, correlationId,
      debug: { route, mode, score: score !== undefined ? +score.toFixed(3) : undefined, ms: Date.now() - t0, llmUsed: state.llmUsed, semantic: this.kb.isSemantic, guard },
    });

    const user = await this.tools.me(token); // throws AuthError -> 401
    const g = this.guard.checkInput(message, user.id);
    if (!g.ok) return done({ reply: g.reply, source: 'refusal', suggestions: this.kb.suggestions().slice(0, 4) }, 'guard', undefined, g.reason);
    const text = g.text;

    // greetings are instant and need no limits: exact catalogue match on a utility rule
    const exactEarly = this.kb.exact(text);
    if (exactEarly?.kind === 'rule') {
      const r = this.kb.rules.get(exactEarly.id)!;
      if (r.mode === 'U') {
        mode = 'U';
        if (r.id === 'greeting' || r.id === 'help') return done(this.welcome(user), r.id);
        if (r.id === 'escalate_to_support') return done(this.escalateOffer(ctx.lastQuery || text), 'escalate_requested');
      }
    }

    const limited = this.guard.enter(user.id);
    if (limited) return done({ reply: limited, source: 'error' }, 'rate_limit');

    try {
      if (!this.kb.ready) return done({ reply: 'The knowledge base is still loading. Please try again in a few seconds.', source: 'error' }, 'not_ready');

      // ---- 1. an answer to my previous question (confirm / missing entity)? ----
      if (ctx.pending) {
        const r = await this.handlePending(ctx.pending, text, token, user, ctx, state);
        if (r) { mode = this.kb.rules.get(ctx.pending.ruleId)?.mode; return done(r.reply, r.route, r.score); }
      }

      // ---- 2. deterministic exact match: rule alias or bare domain word ----
      const exact = this.kb.exact(text);
      if (exact?.kind === 'domain') {
        mode = 'menu';
        return done(this.domainMenu(exact.id, user), 'domain_menu');
      }
      if (exact?.kind === 'rule') {
        const rule = this.kb.rules.get(exact.id)!;
        mode = rule.mode;
        if (rule.id === 'repeat') return done(await this.repeat(token, user, ctx, state), 'repeat');
        return done(await this.executeRule(rule, token, user, text, ctx, state), 'exact', 1);
      }

      // ---- 3. PDF export of a table ----
      if (PDF_RE.test(text)) return done(await this.pdfRequest(token, user, text, ctx, state), 'pdf_export');

      // ---- 4. semantic match against FAQs and searchable rules ----
      const cands = await this.kb.match(text, 3);
      const best = cands[0];
      const { high, low } = this.kb.thresholds;
      let chosen: Candidate | undefined;
      let route = 'direct';

      const margin = best && cands[1] ? best.score - cands[1].score : 1;
      if (best && (best.score >= high || (best.score >= high - 0.1 && margin >= 0.15))) {
        chosen = best; // confident, or a clear winner by margin: no LLM needed
      } else if (best && best.score >= low) {
        // weak match but the intranet has a real hit: prefer the page over a shaky guess (cheap, no LLM)
        if (best.score < 0.62) {
          const hits = await this.solr.search(text, 3);
          if (hits.length) return done(this.contentReply(hits), 'content_over_weak_match', best.score);
        }
        const pick = await this.classify(text, cands, state);
        if (pick === 'unavailable') return done(this.clarify(cands, text), 'clarify_no_llm', best.score);
        const picked = pick !== 'none' ? cands.find((c) => `${c.kind}:${c.id}` === pick) : undefined;
        // distrust an LLM pick that is itself a weak match (small models sometimes choose a far-off candidate)
        if (picked && picked.score >= low) { chosen = picked; route = 'llm_classified'; }
        else return done(await this.contentOrRefuse(text), 'llm_none_content', best.score);
      } else if (ctx.lastIntent && this.kb.rules.get(ctx.lastIntent)?.mode === 'A' && text.length <= 60 && FOLLOWUP_RE.test(text)) {
        chosen = { kind: 'rule', id: ctx.lastIntent, label: '', score: best?.score ?? 0 };
        route = 'followup';
      }

      if (!chosen) return done(await this.contentOrRefuse(text), 'content_search', best?.score);

      if (chosen.kind === 'faq') {
        const faq = this.kb.faqs.get(chosen.id)!;
        return done({ reply: faq.answer, source: 'faq', intent: faq.id }, route, chosen.score);
      }
      const rule = this.kb.rules.get(chosen.id)!;
      mode = rule.mode;
      return done(await this.executeRule(rule, token, user, text, ctx, state), route, chosen.score);
    } catch (e: any) {
      if (e instanceof AuthError) throw e;
      if (e instanceof BusyError) return done({ reply: 'I am handling a lot of requests right now. Please try again in a few seconds.', source: 'error' }, 'busy');
      if (e instanceof UpstreamError) {
        this.log.warn(e.message);
        return done({ reply: 'I could not reach the HR system just now. Please try again shortly.', source: 'error' }, 'upstream_error');
      }
      if (/solr/i.test(e?.message || '')) {
        this.log.warn(e.message);
        return done({ reply: 'I could not reach the content search just now. Please try again shortly.', source: 'error' }, 'solr_error');
      }
      this.log.error(e?.stack || e);
      return done({ reply: 'Something went wrong. Please try again.', source: 'error' }, 'error');
    } finally {
      this.guard.leave(user.id);
    }
  }

  // ======================= rule execution by mode =======================
  private async executeRule(rule: Rule, token: string, user: Me, text: string, ctx: ChatContext, state: State, preset?: Params): Promise<Reply> {
    if (rule.roles && !rule.roles.includes(user.role)) {
      return { reply: `"${rule.label.replace(/\s*\(.*\)$/, '')}" is available to ${rule.roles.join(' / ')}s only.`, source: 'refusal', suggestions: this.kb.suggestions().slice(0, 4) };
    }

    // Mode B: navigation, direct link, no confirmation
    if (rule.mode === 'B') return { reply: `Here is the page for "${rule.label}":`, source: 'link', intent: rule.id, link: this.exec.link(rule) };

    // Mode C: leaves the conversation or performs a write, so confirm first
    if (rule.mode === 'C') {
      return {
        reply: rule.confirmMessage ?? `Open ${rule.target?.title ?? rule.label} in a new tab?`,
        source: 'confirm', intent: rule.id, confirm: { ruleId: rule.id }, pending: { type: 'confirm', ruleId: rule.id },
      };
    }

    // Mode D without a structured action: ranked content search with extractive excerpts
    if (rule.mode === 'D' && !rule.apiMethodKey) {
      const hits = await this.solr.search(rule.searchQuery ?? text, 3);
      return hits.length ? { ...this.contentReply(hits), intent: rule.id } : this.refuse(text);
    }

    // Mode A (and structured Mode D holiday calendars): collect entities, call the action, format the result
    let params = preset ?? (await this.entities.extract(text, rule.id, state));
    rule = this.refineHolidayRoute(rule, text, params);
    return this.runWithEntities(rule, token, params, state);
  }

  /** Ask for a missing required entity (multi-turn) or run the action. */
  private async runWithEntities(rule: Rule, token: string, params: Params, state: State, tries = 0): Promise<Reply> {
    const missing = this.missingRequired(rule, params);
    if (missing) {
      const e = rule.entities!.find((x) => x.name === missing)!;
      return {
        reply: e.prompt ?? `Please tell me the ${e.label.toLowerCase()}.`, source: 'clarify', intent: rule.id,
        suggestions: e.options, pending: { type: 'entity', ruleId: rule.id, params, ask: e.name, tries },
      };
    }
    try {
      const res = await this.exec.run(rule, token, params);
      return {
        reply: res.reply, table: res.table, source: 'tool', intent: rule.id, params,
        export: res.table && rule.exportable ? { intent: rule.id, params } : undefined,
      };
    } catch (e: any) {
      if (e instanceof MissingEntityError) return this.runWithEntities(rule, token, params, state, tries);
      throw e;
    }
  }

  private missingRequired(rule: Rule, p: Params): string | undefined {
    for (const e of rule.entities ?? []) {
      if (!e.required) continue;
      if (e.type === 'period' && !(p.month || p.from)) return e.name;
      if (e.name === 'office' && !p.office) return e.name;
    }
    return undefined;
  }

  /**
   * Holiday has three variants that share vocabulary but differ in source and scope:
   *  "for me" -> my calendar (HR API) · "across offices / compare" -> all offices (Solr) · a named office -> that office (Solr)
   */
  private refineHolidayRoute(rule: Rule, text: string, p: Params): Rule {
    if (!['holiday', 'holiday_all_offices', 'holiday_office'].includes(rule.id)) return rule;
    const mine = /\b(for me|my|mine)\b/i.test(text);
    const get = (id: string) => this.kb.rules.get(id) ?? rule;
    if (HOLIDAY_ALL_RE.test(text)) return get('holiday_all_offices');
    if (p.office && !mine) return get('holiday_office');
    // "for me" / "my" always means the employee's own calendar, even if an office name also appears
    if (mine && rule.id !== 'holiday') return get('holiday');
    return rule;
  }

  // ======================= pending (multi-turn) =======================
  private async handlePending(pd: Pending, text: string, token: string, user: Me, ctx: ChatContext, state: State): Promise<{ reply: Reply; route: string; score?: number } | undefined> {
    const rule = this.kb.rules.get(pd.ruleId);
    if (!rule) return undefined;

    if (pd.type === 'confirm') {
      if (YES_RE.test(text)) return { reply: { reply: `Here you go: ${rule.target?.title ?? rule.label}`, source: 'link', intent: rule.id, link: this.exec.link(rule) }, route: 'confirm_yes' };
      if (NO_RE.test(text)) return { reply: { reply: 'Okay, I will not open it. Is there anything else I can help with?', source: 'info', suggestions: this.kb.suggestions().slice(0, 4) }, route: 'confirm_no' };
      return undefined; // a new question: drop the pending confirmation
    }

    // entity answer: only the deterministic extractor is used for a short reply ("last month", "Chennai")
    const got = this.entities.extractQuick(text, rule.id);
    const merged: Params = { ...(pd.params ?? {}), ...got };
    if (!this.missingRequired(rule, merged)) {
      return { reply: await this.runWithEntities(this.refineHolidayRoute(rule, text, merged), token, merged, state), route: 'entity_followup' };
    }
    // not an answer: is it a different question? then drop the pending state and handle it normally
    if (this.kb.exact(text)) return undefined;
    const best = (await this.kb.match(text, 1))[0];
    if (best && best.score >= this.kb.thresholds.high && !(best.kind === 'rule' && best.id === rule.id)) return undefined;
    if ((pd.tries ?? 0) >= 1) return { reply: { reply: 'Okay, let us leave that for now. What else can I help you with?', source: 'info', suggestions: this.kb.suggestions().slice(0, 4) }, route: 'entity_gave_up' };
    return { reply: await this.runWithEntities(rule, token, pd.params ?? {}, state, (pd.tries ?? 0) + 1), route: 'entity_reprompt' };
  }

  // ======================= menus, welcome, repeat, escalate =======================
  private domainMenu(domainId: string, user: Me): Reply {
    const d = this.kb.domains.get(domainId)!;
    const options = d.options.map((id) => this.kb.rules.get(id)).filter((r): r is Rule => !!r && (!r.roles || r.roles.includes(user.role)));
    return { reply: d.menuPrompt, source: 'menu', suggestions: options.map((r) => r.label) };
  }

  private welcome(user: Me): Reply {
    const first = user.name.split(' ')[0];
    const cats = [...new Set([...this.kb.faqs.values()].map((f) => f.category).filter(Boolean))].join(', ');
    const mgr = user.role === 'manager' ? '\n• Manager tools: team attendance and leave approvals (opened in MyEquations after you confirm)' : '';
    return {
      source: 'greeting',
      reply:
        `Hi ${first}! I'm your HR Assistant. Here is what I can do:\n\n` +
        `• Attendance: your present / late / WFH / absent days for a month, a date range or the last few days\n` +
        `• Leave: your balance (casual / sick / annual), your leave history, and how to apply\n` +
        `• Holidays: your calendar, a specific holiday, upcoming or optional holidays, long weekends, and holidays across Nayara offices or for one office\n` +
        `• Services: payslip, ID card, visitor pass, training, facility booking and travel links\n` +
        `• Company content: policies, guides and news from the intranet\n` +
        `• Company FAQs${cats ? ` (${cats})` : ''}\n` +
        `• PDF download: ask "give me this in pdf" after any table${mgr}\n\n` +
        `Type just a topic such as "leave" or "holiday" to see the options. I can only answer approved questions and I only see your own data. Try one of these:`,
      suggestions: [...this.kb.suggestions().slice(0, 4), 'Show my attendance last month as pdf'],
    };
  }

  private async repeat(token: string, user: Me, ctx: ChatContext, state: State): Promise<Reply> {
    const rule = ctx.lastIntent ? this.kb.rules.get(ctx.lastIntent) : undefined;
    if (rule && rule.mode === 'A' && ctx.lastParams) return this.executeRule(rule, token, user, '', ctx, state, ctx.lastParams);
    if (ctx.lastReply) return { reply: ctx.lastReply, source: 'info' };
    return { reply: 'There is nothing to repeat yet. What would you like to know?', source: 'info', suggestions: this.kb.suggestions().slice(0, 4) };
  }

  private escalateOffer(query: string): Reply {
    return {
      reply: 'I can send your question to HR support so a person can follow up. Would you like me to do that?',
      source: 'info', escalate: { query },
    };
  }

  // ======================= pdf =======================
  /** "give me this in pdf", "attendance for august as pdf": resolve what to export, return an export reference. */
  private async pdfRequest(token: string, user: Me, text: string, ctx: ChatContext, state: State): Promise<Reply> {
    const cleaned = text
      .replace(/\b(pdf|download|export|file|document|please|pls|can you|could you|give me|send me|send|share)\b/gi, ' ')
      .replace(/\s+/g, ' ').trim();
    let rule: Rule | undefined;
    let base: Params = {};
    const best = cleaned ? (await this.kb.match(cleaned, 1))[0] : undefined;
    const matched = best && best.kind === 'rule' && best.score >= this.kb.thresholds.low ? this.kb.rules.get(best.id) : undefined;
    const last = ctx.lastIntent ? this.kb.rules.get(ctx.lastIntent) : undefined;
    if (matched?.exportable) rule = matched;
    else if (last?.exportable) { rule = last; base = ctx.lastParams ?? {}; }
    if (!rule) {
      return {
        reply: 'I can export your attendance, leave balance, leave history and holiday tables as a PDF. Which one would you like?',
        source: 'clarify',
        suggestions: ['Show my attendance last month as pdf', 'Leave history as pdf', 'Holiday calendar as pdf', 'Leave balance as pdf'],
      };
    }
    const extracted: any = await this.entities.extract(cleaned, rule.id, state);
    if (!extracted.upcoming) delete extracted.upcoming;
    let params: Params = { ...base, ...extracted };
    rule = this.refineHolidayRoute(rule, cleaned, params);
    const r = await this.runWithEntities(rule, token, params, state);
    if (r.pending || !r.table || !r.export) return r; // asked a question, or nothing to export
    return { ...r, reply: `Here is the PDF for "${this.kb.rules.get(r.intent!)?.label ?? 'your report'}". Your download should start automatically; if not, use the button below.`, autoDownload: true };
  }

  // ======================= routing helpers =======================
  private asQuestion(c: Candidate): string {
    if (c.kind === 'faq') return this.kb.faqs.get(c.id)?.question ?? c.label;
    const ex = this.kb.rules.get(c.id)?.sampleUtterances[0] ?? c.label;
    return ex.charAt(0).toUpperCase() + ex.slice(1) + (ex.endsWith('?') ? '' : '?');
  }

  /** Not an FAQ or rule: try the intranet (Solr). Refuse only if nothing relevant is indexed. */
  private async contentOrRefuse(text: string): Promise<Reply> {
    const hits = await this.solr.search(text, 3);
    return hits.length ? this.contentReply(hits) : this.refuse(text);
  }

  private contentReply(hits: Awaited<ReturnType<SolrService['search']>>): Reply {
    return {
      source: 'content',
      reply: hits.length === 1 ? 'I found this page on the company intranet:' : `I found ${hits.length} pages on the company intranet that may help:`,
      sources: hits.map(({ title, url, type, snippet, updated, sim }) => ({ title, url, type, snippet, updated, relevance: sim })),
    };
  }

  /** No match anywhere. Besides refusing, offer to escalate (a user-facing path) and the query is logged as a catalogue candidate. */
  private refuse(query: string): Reply {
    return {
      reply: 'I can only help with HR topics I am set up for: attendance, leave, holidays, services and company policy questions. Try one of these, or I can pass your question to HR support:',
      source: 'refusal', suggestions: this.kb.suggestions().slice(0, 5), escalate: { query },
    };
  }

  private clarify(cands: Candidate[], query: string): Reply {
    return { reply: 'I am not sure I understood. Did you mean one of these?', source: 'clarify', suggestions: cands.map((c) => this.asQuestion(c)), escalate: { query } };
  }

  private async classify(text: string, cands: Candidate[], state: State): Promise<string> {
    if (!config.useLlm) return 'unavailable';
    const keys = cands.map((c) => `${c.kind}:${c.id}`);
    const list = cands.map((c, i) => `${i + 1}. [${keys[i]}] ${this.asQuestion(c)}`).join('\n');
    try {
      state.llmUsed = true;
      const out = await this.llm.json<{ choice: string }>(
        'You route employee questions for an HR assistant. Pick the candidate that asks for the same thing as the user message. If none clearly matches, answer "none". Never answer the question yourself.',
        `Candidates:\n${list}\n\nUser message: """${text}"""`,
        { type: 'object', properties: { choice: { type: 'string', enum: [...keys, 'none'] } }, required: ['choice'], additionalProperties: false },
        24,
      );
      return out.choice;
    } catch (e: any) {
      // overloaded or down: degrade to "did you mean…" suggestions rather than failing
      this.log.warn(`classify unavailable: ${e?.message}`);
      return 'unavailable';
    }
  }
}
