import { Injectable } from '@nestjs/common';
import { config } from './config';

export type LeaveType = 'annual' | 'sick' | 'casual';
export interface Params {
  month?: number; year?: number;
  from?: string; to?: string;            // inclusive date range, YYYY-MM-DD
  leaveType?: LeaveType; status?: string;
  upcoming?: boolean;
  holidayName?: string; holidayType?: 'public' | 'optional';
  office?: string;
  relDay?: 'today' | 'tomorrow';
  longWeekend?: boolean;
}
export interface ToolResult { title: string; reply: string; table?: { columns: string[]; rows: string[][] } }
export interface Me { id: string; name: string; department: string; role: string }
export class AuthError extends Error {}
export class UpstreamError extends Error {}

export const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const cap = (s: string) => s.charAt(0).toUpperCase() + s.slice(1);
const nowUtc = () => { const n = new Date(); return { y: n.getUTCFullYear(), m: n.getUTCMonth() + 1, iso: n.toISOString().slice(0, 10) }; };
const addDays = (iso: string, n: number) => new Date(new Date(`${iso}T00:00:00Z`).getTime() + n * 86400000).toISOString().slice(0, 10);
export const fmtDate = (iso: string) => { const d = new Date(`${iso}T00:00:00Z`); return `${d.getUTCDate()} ${MONTHS[d.getUTCMonth()].slice(0, 3)} ${d.getUTCFullYear()}`; };
const dayName = (iso: string) => ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'][new Date(`${iso}T00:00:00Z`).getUTCDay()];

type Method = (token: string, p: Params) => Promise<ToolResult>;

/**
 * The only code that talks to the HR system. Each method is an allow-listed, read-only GET made with
 * the *caller's own token*, selected by the rule's explicit `apiMethodKey` (no URL strings from rules/users).
 */
@Injectable()
export class ToolsService {
  private cache = new Map<string, { exp: number; val: any }>();

  private methods: Record<string, Method> = {
    attendance_overview: (t, p) => this.attendance(t, p),
    quota_overview: (t, p) => this.balance(t, p),
    leave_overview: (t, p) => this.history(t, p),
    view_holidays: (t, p) => this.holidays(t, p),
  };

  has(key: string) { return key in this.methods; }
  run(key: string, token: string, p: Params): Promise<ToolResult> {
    const m = this.methods[key];
    if (!m) throw new Error(`unknown apiMethodKey ${key}`);
    return m(token, p);
  }

  private async get<T>(token: string, path: string, ttlMs: number): Promise<T> {
    const key = `${token}|${path}`;
    const hit = this.cache.get(key);
    if (hit && hit.exp > Date.now()) return hit.val;
    let r: Response;
    try {
      r = await fetch(`${config.hrUrl}${path}`, { headers: { authorization: `Bearer ${token}` }, signal: AbortSignal.timeout(8000) });
    } catch (e: any) { throw new UpstreamError(e?.message || 'HR system unreachable'); }
    if (r.status === 401) throw new AuthError('unauthorized');
    if (!r.ok) throw new UpstreamError(`HR API ${path} -> ${r.status}`);
    const val = (await r.json()) as T;
    this.cache.set(key, { exp: Date.now() + ttlMs, val });
    if (this.cache.size > 5000) this.cache.clear();
    return val;
  }

  me(token: string) { return this.get<Me>(token, '/me', 60_000); }

  // ---------- Mode A: attendance ----------
  private async attendance(token: string, p: Params): Promise<ToolResult> {
    const n = nowUtc();
    let query: string; let label: string;
    if (p.from) {
      const to = p.to ?? p.from;
      query = `from=${p.from}&to=${to}`;
      label = p.from === to ? fmtDate(p.from) : `${fmtDate(p.from)} to ${fmtDate(to)}`;
    } else {
      const year = p.year ?? n.y; const month = p.month ?? n.m;
      query = `month=${year}-${String(month).padStart(2, '0')}`;
      label = `${MONTHS[month - 1]} ${year}`;
    }
    const d: any = await this.get(token, `/attendance?${query}`, 30_000);
    const s = d.summary;
    const title = `Attendance Report - ${label}`;
    if (!d.records.length) return { title, reply: `There are no attendance records for ${label} yet.` };
    return {
      title,
      reply: `Attendance for ${label}: ${s.present} days present (${s.late} late, ${s.wfh} work-from-home), ${s.absent} absent, ${s.leave} on leave. Average ${s.avgHours} hours/day, ${s.totalHours} hours in total.`,
      table: {
        columns: ['Date', 'Day', 'Status', 'In', 'Out', 'Hours'],
        rows: d.records.map((r: any) => [r.date, r.day, r.status === 'leave' ? `leave (${r.leaveType})` : r.mode === 'wfh' && r.checkIn ? `${r.status} (WFH)` : r.status, r.checkIn ?? '-', r.checkOut ?? '-', r.hours ? String(r.hours) : '-']),
      },
    };
  }

  // ---------- Mode A: leave ----------
  private async balance(token: string, p: Params): Promise<ToolResult> {
    const d: any = await this.get(token, '/leave/balance', 30_000);
    const types = (p.leaveType ? [p.leaveType] : ['annual', 'sick', 'casual']) as LeaveType[];
    const rows = types.map((t) => { const b = d.balances[t]; return [cap(t), String(b.entitled), String(b.used), String(b.pending), String(b.available)]; });
    const reply = p.leaveType
      ? `You have ${d.balances[p.leaveType].available} ${p.leaveType} leave day(s) available in ${d.year} (${d.balances[p.leaveType].used} used, ${d.balances[p.leaveType].pending} pending approval).`
      : `Here is your leave balance for ${d.year}.`;
    return { title: `Leave Balance - ${d.year}`, reply, table: { columns: ['Type', 'Entitled', 'Used', 'Pending', 'Available'], rows } };
  }

  private async history(token: string, p: Params): Promise<ToolResult> {
    const year = p.year ?? nowUtc().y;
    const d: any = await this.get(token, `/leave/history?year=${year}`, 30_000);
    let leaves = d.leaves as any[];
    if (p.leaveType) leaves = leaves.filter((l) => l.type === p.leaveType);
    if (p.status) leaves = leaves.filter((l) => l.status === p.status);
    if (!leaves.length) return { title: `Leave History - ${year}`, reply: `No ${[p.status, p.leaveType].filter(Boolean).join(' ')} leave records found for ${year}.`.replace('No  ', 'No ') };
    const days = leaves.filter((l) => l.status === 'approved').reduce((s, l) => s + l.days, 0);
    return {
      title: `Leave History - ${year}`,
      reply: `You have ${leaves.length} ${p.leaveType ? p.leaveType + ' ' : ''}leave request(s) in ${year} (${days} approved day(s)).`,
      table: { columns: ['From', 'To', 'Type', 'Days', 'Status', 'Reason'], rows: leaves.map((l) => [l.from, l.to, cap(l.type), String(l.days), l.status, l.reason]) },
    };
  }

  // ---------- Mode A: personal holidays (employee's own base location; the API has no location parameter) ----------
  private async holidays(token: string, p: Params): Promise<ToolResult> {
    const n = nowUtc();
    const year = p.year ?? n.y;
    const d: any = await this.get(token, `/holidays?year=${year}`, 24 * 3600_000);
    const tag = (arr: any[], type: string) => (arr ?? []).map((h) => ({ ...h, type }));
    let list = [
      ...(p.holidayType === 'optional' ? [] : tag(d.holidays, 'Public')),
      ...(p.holidayType === 'public' ? [] : tag(d.optionalHolidays, 'Optional')),
    ].sort((a, b) => a.date.localeCompare(b.date));
    const typeWord = p.holidayType ? `${p.holidayType} ` : '';
    const row = (h: any) => [h.date, h.day, h.name, h.type];
    const columns = ['Date', 'Day', 'Holiday', 'Type'];

    // "is today / tomorrow a holiday"
    if (p.relDay) {
      const date = p.relDay === 'today' ? n.iso : addDays(n.iso, 1);
      const hit = list.find((h) => h.date === date);
      const when = `${p.relDay} (${dayName(date)}, ${fmtDate(date)})`;
      return {
        title: `Holiday check - ${fmtDate(date)}`,
        reply: hit ? `Yes, ${when} is a ${hit.type.toLowerCase()} holiday: ${hit.name}.` : `No, ${when} is not a holiday.`,
        table: hit ? { columns, rows: [row(hit)] } : undefined,
      };
    }

    // a specific holiday ("when is Diwali for me", "is Christmas a holiday")
    if (p.holidayName) {
      const key = p.holidayName.toLowerCase();
      const hits = list.filter((h) => h.name.toLowerCase().includes(key));
      if (!hits.length) return { title: `${p.holidayName} - ${year}`, reply: `I could not find ${p.holidayName} in your ${typeWord}holiday calendar for ${year}.` };
      const h = hits[0];
      return {
        title: `${h.name} - ${year}`,
        reply: `Yes, ${h.name} is a ${h.type.toLowerCase()} holiday for you on ${dayName(h.date)}, ${fmtDate(h.date)}.`,
        table: { columns, rows: hits.map(row) },
      };
    }

    if (p.from) list = list.filter((h) => h.date >= p.from! && h.date <= (p.to ?? p.from!));
    else if (p.month) list = list.filter((h) => Number(h.date.slice(5, 7)) === p.month);
    const scope = p.from ? `${fmtDate(p.from)} to ${fmtDate(p.to ?? p.from)}` : p.month ? `${MONTHS[p.month - 1]} ${year}` : String(year);

    // long weekends: a holiday on a Friday or Monday forms a 3-day weekend
    if (p.longWeekend) {
      const lw = list.filter((h) => h.type === 'Public' && (dayName(h.date) === 'Fri' || dayName(h.date) === 'Mon'));
      if (!lw.length) return { title: `Long weekends - ${scope}`, reply: `I do not see a long weekend from public holidays in ${scope}.` };
      const rows = lw.map((h) => {
        const fri = dayName(h.date) === 'Fri';
        return [fri ? h.date : addDays(h.date, -3), fri ? addDays(h.date, 2) : h.date, h.name, '3 days'];
      });
      return {
        title: `Long weekends - ${scope}`,
        reply: `You have ${lw.length} long weekend(s) in ${scope}, for example ${lw[0].name} on ${dayName(lw[0].date)}, ${fmtDate(lw[0].date)}.`,
        table: { columns: ['From', 'To', 'Holiday', 'Length'], rows },
      };
    }

    if (p.upcoming) {
      const next = list.filter((h) => h.date >= n.iso).slice(0, 3);
      if (!next.length) return { title: `Upcoming Holidays - ${year}`, reply: `There are no more ${typeWord}holidays left in ${year}.` };
      return { title: `Upcoming Holidays - ${year}`, reply: `The next ${typeWord}holiday is ${next[0].name} on ${dayName(next[0].date)}, ${fmtDate(next[0].date)}.`, table: { columns, rows: next.map(row) } };
    }

    if (!list.length) return { title: `Holidays - ${scope}`, reply: `You have no ${typeWord}holidays in ${scope}.` };
    return {
      title: `${cap(typeWord)}Holiday Calendar - ${scope}`.replace(/^ /, ''),
      reply: `You have ${list.length} ${typeWord}holiday(s) in ${scope}.`,
      table: { columns, rows: list.map(row) },
    };
  }
}
