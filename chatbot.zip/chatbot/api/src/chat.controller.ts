import { BadRequestException, Body, Controller, Get, Header, Headers, HttpCode, NotFoundException, Post, Res, ServiceUnavailableException, UnauthorizedException } from '@nestjs/common';
import { Response } from 'express';
import { ChatContext, ChatService } from './chat.service';
import { config } from './config';
import { EmbeddingService } from './embedding.service';
import { EscalationService } from './escalation.service';
import { ExecutorService, MissingEntityError } from './executor.service';
import { KnowledgeService } from './knowledge.service';
import { LlmService } from './llm.service';
import { PdfService } from './pdf.service';
import { SolrService } from './solr.service';
import { AuthError, Params, ToolsService, UpstreamError } from './tools.service';

const ISO = /^\d{4}-\d{2}-\d{2}$/;
const clean = (v: any, max = 60) => (typeof v === 'string' ? v.replace(/[^\p{L}\p{N} '’.-]/gu, '').slice(0, max) : undefined) || undefined;

@Controller()
export class ChatController {
  constructor(
    private chat: ChatService,
    private kb: KnowledgeService,
    private llm: LlmService,
    private emb: EmbeddingService,
    private tools: ToolsService,
    private pdf: PdfService,
    private solr: SolrService,
    private exec: ExecutorService,
    private esc: EscalationService,
  ) {}

  private bearer(auth: string) {
    const token = (auth || '').replace(/^Bearer\s+/i, '');
    if (!token) throw new UnauthorizedException();
    return token;
  }

  @Post('chat')
  @HttpCode(200)
  async post(@Headers('authorization') auth: string, @Body() body: { message?: string; context?: ChatContext }) {
    const token = this.bearer(auth);
    try {
      return await this.chat.handle(token, String(body?.message ?? ''), body?.context ?? {});
    } catch (e) {
      if (e instanceof AuthError) throw new UnauthorizedException();
      throw e;
    }
  }

  /** Renders a table-type rule result as a PDF. Auth via header (never a URL token); the rule must be exportable and params are whitelisted. */
  @Post('export/pdf')
  @HttpCode(200)
  async exportPdf(@Headers('authorization') auth: string, @Body() body: { intent?: string; params?: any }, @Res() res: Response) {
    const token = this.bearer(auth);
    const rule = this.kb.rules.get(String(body?.intent ?? ''));
    if (!rule || !rule.exportable) throw new BadRequestException('unsupported export');
    const raw = body?.params ?? {};
    const int = (v: any, lo: number, hi: number) => (Number.isInteger(v) && v >= lo && v <= hi ? v : undefined);
    const params: Params = {
      month: int(raw.month, 1, 12), year: int(raw.year, 2000, 2100),
      from: ISO.test(raw.from) ? raw.from : undefined, to: ISO.test(raw.to) ? raw.to : undefined,
      leaveType: ['annual', 'sick', 'casual'].includes(raw.leaveType) ? raw.leaveType : undefined,
      status: ['pending', 'approved', 'rejected'].includes(raw.status) ? raw.status : undefined,
      holidayType: ['public', 'optional'].includes(raw.holidayType) ? raw.holidayType : undefined,
      holidayName: clean(raw.holidayName), office: clean(raw.office),
      relDay: ['today', 'tomorrow'].includes(raw.relDay) ? raw.relDay : undefined,
      upcoming: raw.upcoming === true, longWeekend: raw.longWeekend === true,
    };
    try {
      const user = await this.tools.me(token);
      if (rule.roles && !rule.roles.includes(user.role)) throw new BadRequestException('not allowed for your role');
      const result = await this.exec.run(rule, token, params);
      if (!result.table) throw new BadRequestException(result.reply);
      const pdf = await this.pdf.render({ title: result.title, user, summary: result.reply, table: result.table });
      const filename = result.title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') + '.pdf';
      res.set({
        'Content-Type': 'application/pdf',
        'Content-Disposition': `attachment; filename="${filename}"`,
        'Content-Length': String(pdf.length),
        'Access-Control-Expose-Headers': 'Content-Disposition',
      }).end(pdf);
    } catch (e: any) {
      if (e instanceof AuthError) throw new UnauthorizedException();
      if (e instanceof UpstreamError) throw new ServiceUnavailableException('HR system unreachable');
      if (e instanceof MissingEntityError) throw new BadRequestException(`missing ${e.entity}`);
      if (/solr/i.test(e?.message || '')) throw new ServiceUnavailableException('content search unreachable');
      throw e;
    }
  }

  /** "Send this to HR support": user-facing escalation plus a catalogue-improvement candidate record. */
  @Post('escalate')
  @HttpCode(200)
  async escalate(@Headers('authorization') auth: string, @Body() body: { query?: string; correlationId?: string; note?: string }) {
    const token = this.bearer(auth);
    let user;
    try { user = await this.tools.me(token); } catch (e) { if (e instanceof AuthError) throw new UnauthorizedException(); throw e; }
    const query = String(body?.query ?? '').trim();
    if (!query) throw new BadRequestException('query required');
    return this.esc.record({ userId: user.id, name: user.name, query, correlationId: String(body?.correlationId ?? '').slice(0, 32), note: body?.note });
  }

  @Get('suggestions')
  suggestions() { return { suggestions: this.kb.suggestions() }; }

  /** Demo only: lets the UI offer a user switcher. Remove when wired to real SSO. */
  @Get('demo-users')
  async demoUsers() {
    const r = await fetch(`${config.hrUrl}/demo-users`);
    return r.json();
  }

  @Get('health')
  async health() {
    return {
      ok: true,
      llm: await this.llm.healthy(),
      llmQueue: this.llm.stats,
      embeddings: this.emb.available,
      solr: await this.solr.healthy(),
      knowledge: { faqs: this.kb.faqs.size, rules: this.kb.rules.size, domains: this.kb.domains.size, semantic: this.kb.isSemantic },
    };
  }

  /** Solr synonyms generated from the catalogue and dictionaries (same content as data/generated/synonyms_bot.txt). */
  @Get('admin/synonyms')
  @Header('Content-Type', 'text/plain; charset=utf-8')
  synonyms() {
    if (!this.kb.ready) throw new NotFoundException('catalogue not loaded');
    return this.kb.synonymsFile();
  }

  @Post('admin/reload')
  @HttpCode(200)
  async reload() { await this.kb.reload(); return { faqs: this.kb.faqs.size, rules: this.kb.rules.size, domains: this.kb.domains.size }; }
}
