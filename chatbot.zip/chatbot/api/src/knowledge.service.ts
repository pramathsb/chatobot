import { Injectable, Logger, OnModuleInit } from '@nestjs/common';
import * as ExcelJS from 'exceljs';
import * as fs from 'fs';
import * as path from 'path';
import { Dictionaries, Domain, Rule } from './catalogue';
import { config } from './config';
import { EmbeddingService } from './embedding.service';

export interface FaqEntry { id: string; category: string; question: string; variants: string[]; answer: string }
export interface Candidate { kind: 'faq' | 'rule'; id: string; label: string; score: number }
export type ExactHit = { kind: 'rule'; id: string } | { kind: 'domain'; id: string };

interface IndexItem { kind: 'faq' | 'rule'; id: string; label: string; text: string; tokens: Set<string>; vec?: Float32Array }

const STOP = new Set('a an the is are was were be do does did i me my we our you your to of for in on at and or how what when where which who can could should would will it its this that with about any there have has had get'.split(' '));
const tokenize = (s: string) =>
  new Set(s.toLowerCase().replace(/[^a-z0-9\s]/g, ' ').split(/\s+/).filter((t) => t && !STOP.has(t)).map((t) => t.replace(/(ing|s)$/, '')));

/** lowercase, strip punctuation/politeness, collapse spaces: the form used for exact (deterministic) matching */
export const normalizeExact = (s: string) =>
  s.toLowerCase().replace(/[’']/g, '').replace(/[^a-z0-9\s]/g, ' ').replace(/\s+/g, ' ').trim().replace(/^(please|pls|kindly)\s+/, '');

const escapeRe = (s: string) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

@Injectable()
export class KnowledgeService implements OnModuleInit {
  private log = new Logger('Knowledge');
  faqs = new Map<string, FaqEntry>();
  rules = new Map<string, Rule>();
  domains = new Map<string, Domain>();
  dict: Dictionaries = { holidayNames: {}, quotaTypes: {}, offices: {} };
  private exactIndex = new Map<string, ExactHit>();
  private index: IndexItem[] = [];
  private semantic = false;
  private reloading: Promise<void> | null = null;

  constructor(private emb: EmbeddingService) {}

  async onModuleInit() {
    this.reload(); // do not block startup on model download
    for (const f of ['faq.xlsx', 'faq.json', 'catalogue.json', 'dictionaries.json']) {
      fs.watchFile(path.join(config.dataDir, f), { interval: 3000 }, () => {
        this.log.log(`${f} changed, reloading`);
        this.reload();
      });
    }
  }

  get ready() { return this.index.length > 0; }
  get isSemantic() { return this.semantic; }
  get thresholds() {
    return this.semantic ? { high: config.high, low: config.low } : { high: config.highLex, low: config.lowLex };
  }

  reload(): Promise<void> {
    this.reloading = (this.reloading ?? Promise.resolve()).then(() => this.doReload()).catch((e) => this.log.error(e));
    return this.reloading;
  }

  private readJson<T>(file: string, fallback: T): T {
    const p = path.join(config.dataDir, file);
    return fs.existsSync(p) ? (JSON.parse(fs.readFileSync(p, 'utf8')) as T) : fallback;
  }

  private async doReload() {
    const faqs = new Map<string, FaqEntry>();
    const xlsx = path.join(config.dataDir, 'faq.xlsx');
    const json = path.join(config.dataDir, 'faq.json');
    if (fs.existsSync(xlsx)) for (const f of await this.readXlsx(xlsx)) faqs.set(f.id, f);
    if (fs.existsSync(json)) for (const f of this.readFaqJson(json)) faqs.set(f.id, f);

    const cat = this.readJson<{ rules: Rule[]; domains: Domain[] }>('catalogue.json', { rules: [], domains: [] });
    const rules = new Map<string, Rule>();
    for (const r of cat.rules) {
      if (r.active === false) continue;
      // the button label must always route back to this rule
      rules.set(r.id, { ...r, aliases: [...new Set([r.label, ...r.aliases])] });
    }
    const domains = new Map<string, Domain>(cat.domains.map((d) => [d.id, d]));
    const dict = this.readJson<Dictionaries>('dictionaries.json', { holidayNames: {}, quotaTypes: {}, offices: {} });

    // deterministic index: exact searchTerm / alias for rules, exact aliases for bare domain words
    const exact = new Map<string, ExactHit>();
    for (const r of [...rules.values()].sort((a, b) => (a.priority ?? 0) - (b.priority ?? 0))) {
      for (const a of [r.searchTerm, ...r.aliases]) exact.set(normalizeExact(a), { kind: 'rule', id: r.id });
    }
    // a bare domain word ("leave", "holiday") must show the menu even if a rule shares that word, so domains are added last and win
    for (const d of domains.values()) for (const a of [d.id, ...d.aliases]) exact.set(normalizeExact(a), { kind: 'domain', id: d.id });

    // semantic index: FAQ phrases + searchable rule phrases (never domains/utility)
    const items: IndexItem[] = [];
    for (const f of faqs.values()) {
      for (const t of [f.question, ...f.variants]) items.push({ kind: 'faq', id: f.id, label: f.question, text: t, tokens: tokenize(t) });
    }
    for (const r of rules.values()) {
      if (r.searchable === false) continue;
      for (const t of [r.searchTerm, ...r.aliases, ...r.sampleUtterances]) {
        items.push({ kind: 'rule', id: r.id, label: r.label, text: this.canonicalizeWith(t, dict), tokens: tokenize(t) });
      }
    }

    // lexical index is usable immediately; vectors are added once the embedder is up
    this.faqs = faqs; this.rules = rules; this.domains = domains; this.dict = dict; this.exactIndex = exact;
    this.index = items; this.semantic = false;
    this.log.log(`loaded ${faqs.size} FAQs, ${rules.size} rules, ${domains.size} domains (${items.length} phrases)`);
    this.exportSynonyms();

    if (await this.emb.whenReady()) {
      for (const it of items) it.vec = await this.emb.embed(it.text);
      this.index = items; this.semantic = true;
      this.log.log('semantic index built');
    }
  }

  // ---------- deterministic matching ----------
  exact(text: string): ExactHit | undefined { return this.exactIndex.get(normalizeExact(text)); }

  /** Replace spelling variants of holiday names with the canonical name ("deepavali" -> "Diwali"). */
  canonicalize(text: string): string { return this.canonicalizeWith(text, this.dict); }
  private canonicalizeWith(text: string, dict: Dictionaries): string {
    let out = text;
    const pairs: Array<[string, string]> = [];
    // holiday names and office names are normalised to their canonical spelling ("deepavali" -> "Diwali", "bombay" -> "Mumbai")
    for (const group of [dict.holidayNames, dict.offices]) {
      for (const [canon, variants] of Object.entries(group ?? {})) for (const v of variants) pairs.push([v, canon]);
    }
    pairs.sort((a, b) => b[0].length - a[0].length);
    for (const [v, canon] of pairs) out = out.replace(new RegExp(`\\b${escapeRe(v)}\\b`, 'gi'), canon);
    return out;
  }

  /** First canonical key of a dictionary whose canonical name or variant appears in the text (longest variant wins). */
  findInDictionary(text: string, name: keyof Dictionaries): string | undefined {
    const pairs: Array<[string, string]> = [];
    for (const [canon, variants] of Object.entries(this.dict[name])) for (const v of [canon, ...variants]) pairs.push([v, canon]);
    pairs.sort((a, b) => b[0].length - a[0].length);
    const t = text.toLowerCase().replace(/[’']/g, '');
    for (const [v, canon] of pairs) if (new RegExp(`\\b${escapeRe(v.toLowerCase().replace(/[’']/g, ''))}\\b`).test(t)) return canon;
    return undefined;
  }

  /** Exports aliases + dictionaries as a Solr synonyms file, so Solr and the catalogue stay in sync by construction. */
  synonymsFile(): string {
    const lines: string[] = ['# generated from catalogue.json + dictionaries.json: do not edit by hand'];
    for (const r of this.rules.values()) {
      const set = [...new Set([r.searchTerm, ...r.aliases].map((s) => s.toLowerCase().replace(/[,=>]/g, ' ').trim()))];
      if (set.length > 1) lines.push(set.join(', '));
    }
    for (const group of [this.dict.holidayNames, this.dict.quotaTypes, this.dict.offices]) {
      for (const [canon, variants] of Object.entries(group ?? {})) {
        const v = variants.filter((x) => x.toLowerCase() !== canon.toLowerCase());
        if (v.length) lines.push(`${v.join(', ').toLowerCase()} => ${canon.toLowerCase()}`);
      }
    }
    return lines.join('\n') + '\n';
  }

  private exportSynonyms() {
    try {
      const dir = path.join(config.dataDir, 'generated');
      fs.mkdirSync(dir, { recursive: true });
      fs.writeFileSync(path.join(dir, 'synonyms_bot.txt'), this.synonymsFile());
    } catch (e: any) { this.log.warn(`could not write synonyms file: ${e?.message}`); }
  }

  // ---------- FAQ loaders ----------
  private async readXlsx(file: string): Promise<FaqEntry[]> {
    const wb = new ExcelJS.Workbook();
    await wb.xlsx.readFile(file);
    const ws = wb.worksheets[0];
    const header: Record<string, number> = {};
    ws.getRow(1).eachCell((c, n) => { header[String(c.text).trim().toLowerCase()] = n; });
    const out: FaqEntry[] = [];
    ws.eachRow((row, n) => {
      if (n === 1) return;
      const get = (k: string) => (header[k] ? String(row.getCell(header[k]).text ?? '').trim() : '');
      const question = get('question'); const answer = get('answer');
      if (!question || !answer) return;
      out.push({
        id: get('id') || `xlsx-${n}`, category: get('category'), question, answer,
        variants: get('variants').split(/[;\n]/).map((s) => s.trim()).filter(Boolean),
      });
    });
    return out;
  }

  private readFaqJson(file: string): FaqEntry[] {
    const raw = JSON.parse(fs.readFileSync(file, 'utf8')) as any[];
    return raw
      .filter((r) => r.question && r.answer)
      .map((r, i) => ({
        id: r.id || `json-${i + 1}`, category: r.category || '', question: r.question, answer: r.answer,
        variants: Array.isArray(r.variants) ? r.variants : String(r.variants || '').split(';').map((s) => s.trim()).filter(Boolean),
      }));
  }

  /** Best score per FAQ / rule, sorted descending. */
  async match(query: string, topK = 3): Promise<Candidate[]> {
    const best = new Map<string, Candidate>();
    const q = this.canonicalize(query);
    let qv: Float32Array | undefined;
    const semantic = this.semantic && this.emb.available;
    if (semantic) qv = await this.emb.embed(q);
    const qt = tokenize(q);
    for (const it of this.index) {
      let score: number;
      if (semantic && qv && it.vec) {
        score = 0; for (let k = 0; k < qv.length; k++) score += qv[k] * it.vec[k];
      } else {
        let inter = 0; for (const t of qt) if (it.tokens.has(t)) inter++;
        score = qt.size && it.tokens.size ? inter / Math.sqrt(qt.size * it.tokens.size) : 0;
      }
      const key = `${it.kind}:${it.id}`;
      const cur = best.get(key);
      if (!cur || score > cur.score) best.set(key, { kind: it.kind, id: it.id, label: it.label, score });
    }
    return [...best.values()].sort((a, b) => b.score - a.score).slice(0, topK);
  }

  /** Starter chips: one natural question per Mode A rule, then a few FAQs. */
  suggestions(): string[] {
    const s: string[] = [];
    for (const r of this.rules.values()) if (r.mode === 'A' && r.sampleUtterances[0]) s.push(cap(r.sampleUtterances[0]));
    for (const f of [...this.faqs.values()].slice(0, 3)) s.push(f.question);
    return s;
  }
}

const cap = (s: string) => s.charAt(0).toUpperCase() + s.slice(1) + (s.endsWith('?') ? '' : '?');
