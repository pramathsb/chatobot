import { Injectable } from '@nestjs/common';
import { config } from './config';

export type GuardResult = { ok: true; text: string } | { ok: false; reason: string; reply: string };

const INJECTION = [
  /ignore (all |any |the )?(previous|prior|above|earlier) (instructions|rules|prompts?)/i,
  /(reveal|show|print|repeat).{0,30}(system|hidden|initial) (prompt|instructions)/i,
  /you are now\b/i,
  /\b(jailbreak|developer mode|dan mode)\b/i,
  /pretend (to be|you are)/i,
  /act as (an?|the)\b/i,
];

@Injectable()
export class GuardService {
  private hits = new Map<string, number[]>();
  private busy = new Set<string>();

  /** Input checks that run before any model is touched. */
  checkInput(raw: string, selfId: string): GuardResult {
    const text = (raw || '').replace(/[\u0000-\u001f\u007f]/g, ' ').trim();
    if (!text) return { ok: false, reason: 'empty', reply: 'Please type a question.' };
    if (text.length > config.maxMessageLen) return { ok: false, reason: 'too_long', reply: `Please keep your question under ${config.maxMessageLen} characters.` };
    if (INJECTION.some((r) => r.test(text))) return { ok: false, reason: 'injection', reply: 'I can only answer the approved HR questions. I cannot change my instructions.' };
    const other = text.match(/\bemp\s*0*(\d{1,3})\b/i);
    if (other && `emp${other[1].padStart(3, '0')}` !== selfId) {
      return { ok: false, reason: 'other_user', reply: 'I can only share your own attendance and leave information.' };
    }
    if (/\b(my (colleague|manager|team|boss)|someone else|his|her|their)\b.*\b(leave|attendance|balance)\b/i.test(text)) {
      return { ok: false, reason: 'other_user', reply: 'I can only share your own attendance and leave information.' };
    }
    return { ok: true, text };
  }

  /** Sliding-window rate limit plus one in-flight request per user. Returns an error string or null. */
  enter(userId: string): string | null {
    const now = Date.now();
    const arr = (this.hits.get(userId) || []).filter((t) => now - t < 60_000);
    if (arr.length >= config.userMaxPerMinute) return 'You are sending messages too quickly. Please wait a moment.';
    if (this.busy.has(userId)) return 'Still working on your previous question…';
    arr.push(now); this.hits.set(userId, arr); this.busy.add(userId);
    return null;
  }
  leave(userId: string) { this.busy.delete(userId); }
}
