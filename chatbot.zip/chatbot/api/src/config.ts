const num = (v: string | undefined, d: number) => (v !== undefined && v !== '' ? Number(v) : d);

export const config = {
  port: num(process.env.PORT, 3000),
  hrUrl: process.env.HR_API_URL || 'http://mock-hr:4000',
  llmUrl: process.env.LLM_URL || 'http://llm:8080',
  dataDir: process.env.DATA_DIR || '/app/data',
  modelCache: process.env.MODEL_CACHE || '/models',
  // number of LLM calls allowed in flight (match llama-server -np) and max waiting
  llmConcurrency: num(process.env.LLM_CONCURRENCY, 4),
  llmQueueMax: num(process.env.LLM_QUEUE_MAX, 100),
  llmQueueWaitMs: num(process.env.LLM_QUEUE_WAIT_MS, 4000), // max time a call may wait for a free slot
  llmTimeoutMs: num(process.env.LLM_TIMEOUT_MS, 15000),
  useLlm: (process.env.USE_LLM ?? 'true') === 'true',
  // semantic thresholds (embedding cosine); lexical fallback uses the *Lex values
  high: num(process.env.MATCH_HIGH, 0.75),
  low: num(process.env.MATCH_LOW, 0.5),
  highLex: 0.6,
  lowLex: 0.3,
  solrUrl: process.env.SOLR_URL || 'http://solr:8983/solr/content',
  intranetBaseUrl: (process.env.INTRANET_BASE_URL || 'https://intranet.example.com').replace(/\/$/, ''),
  solrMinScore: num(process.env.SOLR_MIN_SCORE, 1.5), // top hit must score at least this (BM25, unnormalised)
  solrRelative: num(process.env.SOLR_RELATIVE, 0.4), // other hits must reach this fraction of the top score
  solrTimeoutMs: num(process.env.SOLR_TIMEOUT_MS, 4000),
  myequationsBaseUrl: (process.env.MYEQUATIONS_BASE_URL || 'https://myequations.example.com').replace(/\/$/, ''),
  solrMinSim: num(process.env.SOLR_MIN_SIM, 0.37), // semantic check: question vs title or excerpt (cosine)
  maxMessageLen: 500,
  userMaxPerMinute: num(process.env.USER_MAX_PER_MIN, 20),
};
