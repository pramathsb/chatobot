import { Injectable, Logger } from '@nestjs/common';
import { config } from './config';
import { EmbeddingService } from './embedding.service';

export interface ContentHit { title: string; url: string; type: string; updated?: string; snippet: string; score: number; sim?: number }

/**
 * Read-only client for the Solr core that indexes Drupal content.
 * Keyword (BM25) search with highlighted passages. Answers are extractive: the bot only ever
 * shows text that exists in an indexed page, and refuses when nothing relevant is found.
 */
@Injectable()
export class SolrService {
  private log = new Logger('Solr');
  private titleVec = new Map<string, Float32Array>();

  constructor(private emb: EmbeddingService) {}

  async healthy(): Promise<boolean> {
    try {
      const r = await fetch(`${config.solrUrl}/admin/ping?wt=json`, { signal: AbortSignal.timeout(2000) });
      return r.ok;
    } catch { return false; }
  }

  /**
   * Structured (filter-only) query over the per-office holiday calendar content type.
   * Unlike `search`, there is no keyword scoring: office / holiday name are exact filters on indexed fields.
   * Throws UpstreamError-like Error when Solr is unreachable so the caller can say so instead of "no results".
   */
  async holidayDocs(f: { office?: string; holidayName?: string }): Promise<HolidayDoc[]> {
    const esc = (s: string) => `"${s.replace(/["\\]/g, ' ')}"`;
    const params = new URLSearchParams({ q: '*:*', rows: '500', fl: 'office,holiday_name,holiday_date', sort: 'holiday_date asc', wt: 'json' });
    params.append('fq', 'type:holiday_calendar');
    if (f.office) params.append('fq', `office:${esc(f.office)}`);
    if (f.holidayName) params.append('fq', `holiday_name:${esc(f.holidayName)}`);
    let r: Response;
    try {
      r = await fetch(`${config.solrUrl}/select?${params}`, { signal: AbortSignal.timeout(config.solrTimeoutMs) });
    } catch (e: any) { throw new Error(`solr unreachable: ${e?.message}`); }
    if (!r.ok) throw new Error(`solr http ${r.status}`);
    const d: any = await r.json();
    return (d.response?.docs ?? []).map((x: any) => ({ office: x.office, name: x.holiday_name, date: String(x.holiday_date).slice(0, 10) }));
  }

  /**
   * Keyword search cannot tell "programming language" from "referral program" (same word stem).
   * Keep only hits whose title or excerpt is close in *meaning* to the question. Skipped if the embedder is unavailable.
   */
  private async verify(question: string, hits: ContentHit[]): Promise<ContentHit[]> {
    if (!this.emb.available || !hits.length) return hits;
    const dot = (a: Float32Array, b: Float32Array) => { let s = 0; for (let i = 0; i < a.length; i++) s += a[i] * b[i]; return s; };
    const qv = await this.emb.embed(question);
    const out: ContentHit[] = [];
    for (const h of hits) {
      let tv = this.titleVec.get(h.title);
      if (!tv) { tv = await this.emb.embed(h.title); this.titleVec.set(h.title, tv); }
      const sv = h.snippet ? await this.emb.embed(h.snippet.slice(0, 400)) : undefined;
      h.sim = +Math.max(dot(qv, tv), sv ? dot(qv, sv) : 0).toFixed(3);
      if (h.sim >= config.solrMinSim) out.push(h);
    }
    return out;
  }

  /** Returns [] when nothing relevant is found or Solr is unavailable. */
  async search(text: string, max = 3): Promise<ContentHit[]> {
    // strip Solr syntax so users cannot inject local params, field queries or operators
    const q = text.replace(GENERIC, ' ')
      .replace(/[{}\[\]()^"~*?:\\\/!+\-|&<>]/g, ' ').replace(/\s+/g, ' ').trim();
    if (q.length < 3) return [];

    const params = new URLSearchParams({
      q, defType: 'edismax', qf: 'title^3 tags^2 body', mm: '35%', uf: '-*',
      rows: String(max), fl: 'id,title,url,type,updated,score', wt: 'json',
      hl: 'true', 'hl.fl': 'body', 'hl.method': 'unified', 'hl.snippets': '2', 'hl.fragsize': '260',
      'hl.tag.pre': '', 'hl.tag.post': '', 'hl.defaultSummary': 'true',
    });
    try {
      const r = await fetch(`${config.solrUrl}/select?${params}`, { signal: AbortSignal.timeout(config.solrTimeoutMs) });
      if (!r.ok) throw new Error(`solr http ${r.status}`);
      const d: any = await r.json();
      const docs: any[] = d.response?.docs ?? [];
      if (!docs.length || docs[0].score < config.solrMinScore) return [];
      const hits: ContentHit[] = docs
        .filter((x) => x.score >= docs[0].score * config.solrRelative)
        .map((x) => ({
          title: x.title, url: `${config.intranetBaseUrl}${x.url}`, type: x.type, updated: x.updated, score: +x.score.toFixed(2),
          snippet: clean((d.highlighting?.[x.id]?.body ?? []).join(' ... ')),
        }));
      return await this.verify(text, hits);
    } catch (e: any) {
      this.log.warn(`search failed: ${e?.message}`);
      return [];
    }
  }
}

// words that appear in nearly every intranet page: they add noise (and force wrong 'all terms must match'), not meaning
const GENERIC = /\b(what|whats|how|when|where|who|which|why|can|could|do|does|did|is|are|was|am|i|my|me|we|our|you|your|to|of|in|on|at|for|there|any|about|the|a|an|get|give|tell|search|find|look ?up|look for|show me|tell me about|please|policy|policies|guide|guidelines|program|programme|process|information|info|company|office|employee|employees|intranet|page|pages|document|details)\b/gi;

const clean = (s: string) => s.replace(/<[^>]+>/g, '').replace(/\s+/g, ' ').trim();

export interface HolidayDoc { office: string; name: string; date: string }
