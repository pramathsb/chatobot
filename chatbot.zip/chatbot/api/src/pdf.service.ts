import { Injectable } from '@nestjs/common';
import PDFDocument = require('pdfkit');

export interface PdfInput {
  title: string;
  user: { name: string; id: string; department: string };
  summary?: string;
  table?: { columns: string[]; rows: string[][] };
}

const M = 40;            // page margin
const ROW_H = 18;
const COLOR = { head: '#2f5bea', zebra: '#f3f5fa', line: '#d9dde6', text: '#1d2330', muted: '#6b7280' };

@Injectable()
export class PdfService {
  render(input: PdfInput): Promise<Buffer> {
    return new Promise((resolve, reject) => {
      const doc = new PDFDocument({ size: 'A4', margin: M, bufferPages: true, info: { Title: input.title, Author: 'HR Assistant' } });
      const chunks: Buffer[] = [];
      doc.on('data', (c: Buffer) => chunks.push(c));
      doc.on('end', () => resolve(Buffer.concat(chunks)));
      doc.on('error', reject);

      const width = doc.page.width - 2 * M;

      doc.fillColor(COLOR.head).font('Helvetica-Bold').fontSize(18).text(input.title, M, M);
      doc.moveDown(0.3).fillColor(COLOR.text).font('Helvetica').fontSize(10)
        .text(`Employee: ${input.user.name} (${input.user.id}) · ${input.user.department}`)
        .fillColor(COLOR.muted).text(`Generated: ${new Date().toISOString().slice(0, 16).replace('T', ' ')} UTC`);
      if (input.summary) {
        doc.moveDown(0.8).fillColor(COLOR.text).fontSize(10).text(input.summary, { width });
      }
      doc.moveDown(1);

      if (input.table) this.table(doc, input.table, width);

      // page numbers; bottom margin is zeroed so writing in the footer does not add a page
      const range = doc.bufferedPageRange();
      for (let i = 0; i < range.count; i++) {
        doc.switchToPage(range.start + i);
        doc.page.margins.bottom = 0;
        doc.fillColor(COLOR.muted).font('Helvetica').fontSize(8)
          .text(`Page ${i + 1} of ${range.count}`, M, doc.page.height - 28, { width, align: 'right', lineBreak: false });
      }
      doc.end();
    });
  }

  private table(doc: PDFKit.PDFDocument, t: { columns: string[]; rows: string[][] }, width: number) {
    // column widths proportional to the longest value (clamped), scaled to the page width
    const weights = t.columns.map((c, i) => Math.min(30, Math.max(6, c.length, ...t.rows.map((r) => String(r[i] ?? '').length))));
    const total = weights.reduce((a, b) => a + b, 0);
    const widths = weights.map((w) => (w / total) * width);
    const bottom = doc.page.height - M - 10;

    const header = (y: number) => {
      doc.rect(M, y, width, ROW_H).fill(COLOR.head);
      doc.fillColor('#fff').font('Helvetica-Bold').fontSize(9);
      let x = M;
      t.columns.forEach((c, i) => { doc.text(c, x + 5, y + 5, { width: widths[i] - 8, lineBreak: false, ellipsis: true }); x += widths[i]; });
      return y + ROW_H;
    };

    let y = header(doc.y);
    t.rows.forEach((row, ri) => {
      if (y + ROW_H > bottom) { doc.addPage(); y = header(M); }
      if (ri % 2 === 1) doc.rect(M, y, width, ROW_H).fill(COLOR.zebra);
      doc.fillColor(COLOR.text).font('Helvetica').fontSize(9);
      let x = M;
      row.forEach((v, i) => { doc.text(String(v ?? ''), x + 5, y + 5, { width: widths[i] - 8, lineBreak: false, ellipsis: true }); x += widths[i]; });
      doc.moveTo(M, y + ROW_H).lineTo(M + width, y + ROW_H).strokeColor(COLOR.line).lineWidth(0.5).stroke();
      y += ROW_H;
    });
  }
}
