// Mock HR system: attendance, leave balance, leave history, public holidays.
// Data is generated deterministically per employee so results are stable across calls.
const express = require('express');

const app = express();
const PORT = process.env.PORT || 4000;
const LATENCY = Number(process.env.MOCK_LATENCY_MS || 80);

const USERS = {
  'demo-token-emp001': { id: 'emp001', name: 'Aisha Khan', department: 'Engineering', role: 'employee' },
  'demo-token-emp002': { id: 'emp002', name: 'Rahul Verma', department: 'Finance', role: 'manager' },
  'demo-token-emp003': { id: 'emp003', name: 'Maria Garcia', department: 'HR', role: 'manager' },
  'demo-token-emp004': { id: 'emp004', name: 'John Smith', department: 'Sales', role: 'employee' },
  'demo-token-emp005': { id: 'emp005', name: 'Li Wei', department: 'Operations', role: 'employee' },
};

const ENTITLEMENT = { annual: 20, sick: 10, casual: 8 };

const HOLIDAYS = [
  ['01-01', "New Year's Day"],
  ['01-26', 'Republic Day'],
  ['03-14', 'Holi'],
  ['04-03', 'Good Friday'],
  ['05-01', 'Labour Day'],
  ['08-15', 'Independence Day'],
  ['10-02', 'Gandhi Jayanti'],
  ['10-20', 'Dussehra'],
  ['11-08', 'Diwali'],
  ['12-25', 'Christmas Day'],
];

const OPTIONAL_HOLIDAYS = [
  ['03-04', 'Maha Shivaratri'],
  ['08-28', 'Raksha Bandhan'],
  ['09-04', 'Janmashtami'],
  ['09-14', 'Ganesh Chaturthi'],
  ['11-09', 'Govardhan Puja'],
];

// ---------- helpers (all dates are UTC midnight) ----------
function mulberry32(a) {
  return function () {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const rngFor = (s) => mulberry32([...s].reduce((h, c) => (h * 31 + c.charCodeAt(0)) | 0, 7));
const iso = (d) => d.toISOString().slice(0, 10);
const utc = (y, m, d) => new Date(Date.UTC(y, m, d));
const addDays = (d, n) => new Date(d.getTime() + n * 86400000);
const isWeekend = (d) => d.getUTCDay() === 0 || d.getUTCDay() === 6;
const today = () => { const n = new Date(); return utc(n.getUTCFullYear(), n.getUTCMonth(), n.getUTCDate()); };
const DAY = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const hhmm = (mins) => `${String(Math.floor(mins / 60)).padStart(2, '0')}:${String(mins % 60).padStart(2, '0')}`;

function holidaysFor(year, list = HOLIDAYS) {
  return list.map(([md, name]) => {
    const d = new Date(`${year}-${md}T00:00:00Z`);
    return { date: iso(d), day: DAY[d.getUTCDay()], name };
  });
}

function leaveHistoryFor(emp, year) {
  const rng = rngFor(`${emp}-${year}`);
  const t = today();
  const out = [];
  for (let i = 0; i < 6; i++) {
    let start = utc(year, Math.floor(rng() * 12), 1 + Math.floor(rng() * 25));
    while (isWeekend(start)) start = addDays(start, 1);
    const days = 1 + Math.floor(rng() * 3);
    let end = start; let counted = 1;
    while (counted < days) { end = addDays(end, 1); if (!isWeekend(end)) counted++; }
    const r = rng();
    const type = r < 0.5 ? 'annual' : r < 0.75 ? 'sick' : 'casual';
    const status = start > t ? (rng() < 0.7 ? 'approved' : 'pending') : (rng() < 0.9 ? 'approved' : 'rejected');
    out.push({
      id: `L-${year}-${emp.slice(3)}-${i + 1}`, type, from: iso(start), to: iso(end), days, status,
      reason: { annual: 'Family trip', sick: 'Fever / medical rest', casual: 'Personal work' }[type],
    });
  }
  return out.sort((a, b) => a.from.localeCompare(b.from));
}

function attendanceFor(emp, from, to) {
  const years = []; for (let y = from.getUTCFullYear(); y <= to.getUTCFullYear(); y++) years.push(y);
  const hol = new Set(years.flatMap((y) => holidaysFor(y).map((h) => h.date)));
  const leaves = years.flatMap((y) => leaveHistoryFor(emp, y)).filter((l) => l.status === 'approved');
  const t = today();
  const records = [];
  for (let d = from; d <= to; d = addDays(d, 1)) {
    if (d > t) break;
    const date = iso(d);
    const rec = { date, day: DAY[d.getUTCDay()], status: 'present', checkIn: null, checkOut: null, hours: 0, mode: 'office' };
    const leave = leaves.find((l) => date >= l.from && date <= l.to);
    if (isWeekend(d)) rec.status = 'weekend';
    else if (hol.has(date)) rec.status = 'holiday';
    else if (leave) { rec.status = 'leave'; rec.leaveType = leave.type; }
    else {
      const rng = rngFor(`${emp}-${date}`);
      const r = rng();
      if (r < 0.06 && d < t) rec.status = 'absent';
      else {
        const inM = 535 + Math.floor(rng() * 45) + (r > 0.8 ? 25 : 0); // ~08:55-09:40
        const outM = inM + 480 + Math.floor(rng() * 70) - 20;
        rec.checkIn = hhmm(inM); rec.checkOut = d.getTime() === t.getTime() ? null : hhmm(outM);
        rec.hours = rec.checkOut ? +((outM - inM) / 60).toFixed(1) : 0;
        if (inM > 555 + 15) rec.status = 'late';
        if (r > 0.65 && r < 0.8) rec.mode = 'wfh';
      }
    }
    records.push(rec);
  }
  const c = (f) => records.filter(f).length;
  const worked = records.filter((r) => r.hours > 0);
  return {
    from: iso(from), to: iso(to),
    summary: {
      present: c((r) => r.status === 'present' || r.status === 'late'),
      late: c((r) => r.status === 'late'),
      wfh: c((r) => r.mode === 'wfh' && r.checkIn),
      absent: c((r) => r.status === 'absent'),
      leave: c((r) => r.status === 'leave'),
      holidays: c((r) => r.status === 'holiday'),
      totalHours: +worked.reduce((s, r) => s + r.hours, 0).toFixed(1),
      avgHours: worked.length ? +(worked.reduce((s, r) => s + r.hours, 0) / worked.length).toFixed(1) : 0,
    },
    records,
  };
}

// ---------- middleware / routes ----------
app.use((req, res, next) => setTimeout(next, LATENCY * (0.5 + Math.random())));

app.get('/health', (_req, res) => res.json({ ok: true }));
// demo only: lists tokens so the UI can offer a user switcher
app.get('/demo-users', (_req, res) =>
  res.json(Object.entries(USERS).map(([token, u]) => ({ token, ...u }))));

app.use((req, res, next) => {
  const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
  // synthetic users for load tests: token "load-<n>" -> employee "emp<1000+n>"
  const load = token.match(/^load-(\d{1,5})$/);
  const user = USERS[token] || (load && { id: `emp${1000 + Number(load[1])}`, name: `Load User ${load[1]}`, department: 'LoadTest', role: 'employee' });
  if (!user) return res.status(401).json({ error: 'unauthorized' });
  req.user = user;
  next();
});

app.get('/me', (req, res) => res.json(req.user));

// /attendance?month=YYYY-MM   or   /attendance?from=YYYY-MM-DD&to=YYYY-MM-DD (max 93 days)
app.get('/attendance', (req, res) => {
  const n = new Date();
  let from; let to;
  if (req.query.from || req.query.to) {
    const ok = (s) => /^\d{4}-\d{2}-\d{2}$/.test(s || '') && !isNaN(new Date(`${s}T00:00:00Z`));
    if (!ok(req.query.from) || !ok(req.query.to)) return res.status(400).json({ error: 'from/to must be YYYY-MM-DD' });
    from = new Date(`${req.query.from}T00:00:00Z`); to = new Date(`${req.query.to}T00:00:00Z`);
    if (to < from || (to - from) / 86400000 > 92) return res.status(400).json({ error: 'range must be 1-93 days' });
  } else {
    const ym = req.query.month || `${n.getUTCFullYear()}-${String(n.getUTCMonth() + 1).padStart(2, '0')}`;
    if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(ym)) return res.status(400).json({ error: 'month must be YYYY-MM' });
    const [y, m] = ym.split('-').map(Number);
    from = utc(y, m - 1, 1); to = utc(y, m, 0);
  }
  res.json({ employeeId: req.user.id, ...attendanceFor(req.user.id, from, to) });
});

app.get('/leave/balance', (req, res) => {
  const year = new Date().getUTCFullYear();
  const hist = leaveHistoryFor(req.user.id, year);
  const balances = {};
  for (const [type, entitled] of Object.entries(ENTITLEMENT)) {
    const sum = (st) => hist.filter((l) => l.type === type && l.status === st).reduce((s, l) => s + l.days, 0);
    const used = sum('approved'); const pending = sum('pending');
    balances[type] = { entitled, used, pending, available: entitled - used - pending };
  }
  res.json({ employeeId: req.user.id, year, balances });
});

app.get('/leave/history', (req, res) => {
  const year = Number(req.query.year || new Date().getUTCFullYear());
  if (!(year >= 2000 && year <= 2100)) return res.status(400).json({ error: 'invalid year' });
  res.json({ employeeId: req.user.id, year, leaves: leaveHistoryFor(req.user.id, year) });
});

app.get('/holidays', (req, res) => {
  const year = Number(req.query.year || new Date().getUTCFullYear());
  if (!(year >= 2000 && year <= 2100)) return res.status(400).json({ error: 'invalid year' });
  // public holidays and optional (restricted) holidays are two separate collections, as in the real API
  res.json({ year, holidays: holidaysFor(year), optionalHolidays: holidaysFor(year, OPTIONAL_HOLIDAYS) });
});

app.listen(PORT, () => console.log(`mock-hr listening on :${PORT}`));
