import React, { useEffect, useRef, useState } from 'react';

const WELCOME = {
  role: 'bot',
  reply: 'Hi! Ask me about attendance, leave, holidays or HR services. Type "help" to see everything I can do, or just a topic such as "leave" or "holiday" for options.',
};

function Table({ table }) {
  return (
    <div className="table-wrap">
      <table>
        <thead><tr>{table.columns.map((c) => <th key={c}>{c}</th>)}</tr></thead>
        <tbody>{table.rows.map((r, i) => <tr key={i}>{r.map((v, j) => <td key={j}>{v}</td>)}</tr>)}</tbody>
      </table>
    </div>
  );
}

function Message({ m, isLast, onPick, onDownload, downloading, onEscalate }) {
  if (m.role === 'user') return <div className="msg user"><div className="bubble">{m.text}</div></div>;
  const d = m.debug;
  const cls = m.source === 'refusal' ? 'refusal' : m.source === 'error' ? 'error' : '';
  return (
    <div className="msg bot">
      <div className={`bubble ${cls}`}>
        <div>{m.reply}</div>
        {m.table && <Table table={m.table} />}
        {m.link && (
          <a className="source" href={m.link.url} target="_blank" rel="noopener noreferrer">
            <span className="s-title">{m.link.title}</span>
            {m.link.description && <span className="s-snippet">{m.link.description}</span>}
            <span className="s-url">{m.link.url}</span>
          </a>
        )}
        {m.sources?.map((s) => (
          <a key={s.url} className="source" href={s.url} target="_blank" rel="noopener noreferrer">
            <span className="s-title">{s.title} <em>{s.type}</em></span>
            <span className="s-snippet">{s.snippet}</span>
            <span className="s-url">{s.url}</span>
          </a>
        ))}
        {m.export && (
          <button className="dl" disabled={downloading} onClick={() => onDownload(m.export)}>
            {downloading ? 'Preparing PDF…' : '⬇ Download PDF'}
          </button>
        )}
        {m.confirm && (
          <div className="chips">
            <button disabled={!isLast} onClick={() => onPick('Yes')}>Yes, open it</button>
            <button disabled={!isLast} onClick={() => onPick('No')}>No</button>
          </div>
        )}
        {m.suggestions?.length > 0 && (
          <div className="chips">{m.suggestions.map((s) => <button key={s} onClick={() => onPick(s)}>{s}</button>)}</div>
        )}
        {m.escalate && (
          <div className="chips">
            <button disabled={m.escalated} onClick={() => onEscalate(m)}>{m.escalated ? 'Sent to HR support' : '✉ Send this to HR support'}</button>
          </div>
        )}
        {d && (
          <div className="meta">
            {m.source}{m.intent ? ` · ${m.intent}` : ''} · {d.mode ? `mode ${d.mode} · ` : ''}{d.route}{d.score !== undefined ? ` · score ${d.score}` : ''} · {d.ms} ms{d.llmUsed ? ' · LLM' : ''}
            {m.correlationId ? ` · #${m.correlationId}` : ''}
          </div>
        )}
      </div>
    </div>
  );
}

export default function App() {
  const [users, setUsers] = useState([]);
  const [token, setToken] = useState('');
  const [messages, setMessages] = useState([WELCOME]);
  const [suggestions, setSuggestions] = useState([]);
  const [input, setInput] = useState('');
  const [busy, setBusy] = useState(false);
  // conversation state echoed back to the (stateless) server on every turn
  const [ctx, setCtx] = useState({});
  const [dlBusy, setDlBusy] = useState(false);
  const endRef = useRef(null);

  useEffect(() => {
    fetch('/api/demo-users').then((r) => r.json()).then((u) => { setUsers(u); setToken(u[0]?.token || ''); }).catch(() => {});
    fetch('/api/suggestions').then((r) => r.json()).then((d) => setSuggestions(d.suggestions || [])).catch(() => {});
  }, []);
  useEffect(() => { endRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages, busy]);

  const user = users.find((u) => u.token === token);
  const switchUser = (t) => { setToken(t); setMessages([WELCOME]); setCtx({}); };
  const addBot = (reply, extra = {}) => setMessages((m) => [...m, { role: 'bot', reply, ...extra }]);

  // The token travels in the Authorization header, never in a URL, so fetch the PDF as a blob and save it.
  const download = async (ref) => {
    if (dlBusy) return;
    setDlBusy(true);
    try {
      const r = await fetch('/api/export/pdf', {
        method: 'POST',
        headers: { 'content-type': 'application/json', authorization: `Bearer ${token}` },
        body: JSON.stringify(ref),
      });
      if (!r.ok) throw new Error(r.status === 401 ? 'Your session is not valid.' : 'Could not create the PDF.');
      const name = /filename="([^"]+)"/.exec(r.headers.get('content-disposition') || '')?.[1] || 'report.pdf';
      const url = URL.createObjectURL(await r.blob());
      const a = document.createElement('a');
      a.href = url; a.download = name; document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 10000);
    } catch (e) {
      addBot(e.message, { source: 'error' });
    } finally { setDlBusy(false); }
  };

  const escalate = async (m) => {
    try {
      const r = await fetch('/api/escalate', {
        method: 'POST',
        headers: { 'content-type': 'application/json', authorization: `Bearer ${token}` },
        body: JSON.stringify({ query: m.escalate.query, correlationId: m.correlationId }),
      });
      if (!r.ok) throw new Error('Could not send your request. Please try again.');
      const { ticketId } = await r.json();
      setMessages((all) => all.map((x) => (x === m ? { ...x, escalated: true } : x)));
      addBot(`Done. I sent your question to HR support (reference ${ticketId}). Someone will follow up with you.`, { source: 'info' });
    } catch (e) {
      addBot(e.message, { source: 'error' });
    }
  };

  const send = async (text) => {
    text = (text ?? input).trim();
    if (!text || busy || !token) return;
    setInput(''); setBusy(true);
    setMessages((m) => [...m, { role: 'user', text }]);
    try {
      const r = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'content-type': 'application/json', authorization: `Bearer ${token}` },
        body: JSON.stringify({ message: text, context: ctx }),
      });
      if (r.status === 401) throw new Error('Your session is not valid. Please pick a user again.');
      const data = await r.json();
      setCtx((c) => ({
        lastIntent: data.source === 'tool' ? data.intent : c.lastIntent,
        lastParams: data.source === 'tool' ? data.params : c.lastParams,
        lastReply: (data.reply || '').slice(0, 800),
        lastQuery: ['greeting', 'info', 'link'].includes(data.source) ? c.lastQuery : text,
        pending: data.pending,
      }));
      if (data.autoDownload && data.export) download(data.export);
      setMessages((m) => [...m, { role: 'bot', ...data }]);
    } catch (e) {
      setMessages((m) => [...m, { role: 'bot', source: 'error', reply: e.message || 'Network error.' }]);
    } finally { setBusy(false); }
  };

  return (
    <div className="app">
      <header>
        <h1>HR Assistant <span>POC</span></h1>
        <label>
          Signed in as&nbsp;
          <select value={token} onChange={(e) => switchUser(e.target.value)}>
            {users.map((u) => <option key={u.token} value={u.token}>{u.name} ({u.id}){u.role === 'manager' ? ' · manager' : ''}</option>)}
          </select>
        </label>
      </header>

      <main>
        {messages.map((m, i) => (
          <Message key={i} m={m} isLast={i === messages.length - 1} onPick={send} onDownload={download} downloading={dlBusy} onEscalate={escalate} />
        ))}
        {busy && <div className="msg bot"><div className="bubble typing">Thinking…</div></div>}
        {messages.length === 1 && suggestions.length > 0 && (
          <div className="chips start">{suggestions.map((s) => <button key={s} onClick={() => send(s)}>{s}</button>)}</div>
        )}
        <div ref={endRef} />
      </main>

      <form onSubmit={(e) => { e.preventDefault(); send(); }}>
        <input value={input} onChange={(e) => setInput(e.target.value)} placeholder="Ask about attendance, leave, holidays or policies…" maxLength={500} autoFocus />
        <button disabled={busy || !input.trim()}>Send</button>
      </form>
    </div>
  );
}
